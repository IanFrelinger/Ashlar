From: claude
To: grok
Kind: handoff
About: pr-801

#801 is on feat/ashlarexp002-experimental-security-api at head eb5300f40. It is not merged, and it is rebased onto
1f45a9e5b (#800).

What it applies: the owner's 2026-10-13 rows. The 23 types behind the 160 non-header lines of
src/Ashlar.Abstractions/PublicAPI.Unshipped.txt now carry [Experimental("ASHLAREXP002")]. Those are every public type
in Ashlar.Abstractions.Security and .Security.Egress, plus AshlarResolvedDeploymentProfileOptions.
- The id and its help link (#ashlarexp002) live in the internal, non-experimental
  Ashlar.Abstractions.Security.SecurityExperimental. Making it internal is an integrator decision.
- A cert-gate fact keeps the id inside src/Ashlar.Abstractions/.

Opt-ins:
- One IsTestProject-conditioned NoWarn in Directory.Build.targets.
- One per project file, for the 16 shipped assemblies that NAME a surface type. Each is a reviewed
  DiagnosticSuppressionConventionTests entry, and a dead one fails.
- Four more assemblies depend on the surface through internal friend helpers and need no opt-in: Runtime,
  Mcp.Server, Transport.A2A.Server and Transport.Grpc.Server.

Third review round and the #800 rebase:
- N-a: the CHANGELOG list of SPEC-007 Substrate members that name no surface type now says "for example". It comes
  from a lexical scan of SPEC-007's commits since v0.2.0, and adds AshlarInboundListenerOptions,
  AshlarInboundListenerPolicy.IsLoopbackEndpoint/.CollectEndpoints, AddAshlarInboundListenerValidation,
  NeverFollowRedirects, the 4.8 and 4.8b Dispose methods, AgentCycleResult.EgressRefusals, CapabilityRegistry.Find,
  AshlarPolicy.Clearances and ExtensionPackage.HighestLevel.
- N-b: policy breaking-change step 4 says that promoting an Abstractions experimental symbol also changes
  ExperimentalSecurityApiConventionTests, after a decisions-log row.
- N-c: the probe's sources are kept under exp002-logs/probe-member-access/. The re-run gave the same result.
- F1: the ci/cert-gate-assertions.md Certification count now reads 155 .cs files and 158 entries, measured on the
  rebased tree. Its history ends "...then 152, then 153, then 154, before it read 155".
- CHANGELOG after the rebase: this PR's entry comes first under [Unreleased], and #800's entries are intact.
  git diff origin/master...HEAD -- CHANGELOG.md removes 0 lines.

Evidence:
- Red at the tests-only commit: 6 failed of 163.
- At eb5300f40:
  - green: 168 of 168. The counts are unchanged by #800: security-experimental-declarations=23
    outside-abstractions=0, dead=0.
  - cert-gate: 3353 of 3353, 0 skipped.
  - host gates: 2 of 32 failed, the known host-only ones.
- 13 mutations, all killed. The verdict lines are in the PR body.

Records and docs it touches, for the drift audit:
- docs/SdkCompatibilityPolicy.md:
  - :12, :46, :78, :84, :88;
  - the #ashlarexp002 section, with "What the diagnostic does not see" and the Substrate list;
  - the netstandard2.0 paragraph;
  - breaking-change step 4.
- docs/sdk.md:32.
- CHANGELOG.md [Unreleased] "Changed", first under [Unreleased], above #800's two entries and #798's.
- ci/cert-gate-assertions.md: the new ExperimentalSecurityApiConventionTests row, the extended
  DiagnosticSuppressionConventionTests row, and the Certification count paragraph (155/158).
- docs/specs/SPEC-007-security-labels-and-reference-monitor.md §4.2: "Applied in #801", only.
- docs/knowledge-graph.{json,md}.
- Directory.Build.targets.
- 16 .csproj files: 13 under src/, application/src/Ashlar.API, application/src/Ashlar.CLI, and
  commercial/src/Ashlar.Commercial.MeshDirector.
- Comments in src/Ashlar.Compat/Polyfills/ExperimentalAttribute.cs and
  src/Ashlar.Abstractions/Security/SecurityExperimental.cs.

Counts that are now true, and could drift:
- "23 types / 160 lines".
- "17 reviewed ASHLAREXP002 opt-ins (16 project files)".
- "21 entries in 5 assemblies" (the reflected Substrate exposure list; no gate checks it).
- "four more depend without naming it".
- "155 .cs files / 158 entries" (Certification; the next PR that adds a file there must recount).
