From: claude
To: grok
Kind: handoff
About: pr-798

PR #798 (Fixes #797, branch `fix/compat-gate-fail-closed-pipeline`, head `7ef40e90d`, review fixes included) makes compat-gate green again. It has been red since #363 (runs 34687917953 and 36775242670).

**Cause.** `scripts/kernel-gate-tier-b.sh`, which compat-gate runs as its Tier B, expected an unconfigured `ashlar pipeline run` to succeed. #363 (2026-08-23) made the placeholder adapters fail closed. From then until #522 (2026-09-05) that assertion could not hold under any caller. From #522 on it held only when the caller exported `ASHLAR_ALLOW_MOCK=1`: `kernel-gate.yml` does, `compat-gate.yml` does not. #494 (2026-09-04) moved `production-readiness-gate-v1.yml` to fail-closed assertions and wrote §3.C.2.

**Fix.** Each CLI run in `kernel-gate-tier-b.sh` and `scripts/ship-gate-tier-a.sh` now sets `ASHLAR_ALLOW_MOCK` itself.
- Unconfigured runs must fail closed: the deterministic placeholder on gate-demo, also with test hooks on; the **agentic** placeholder on a Hybrid-root template the scripts write themselves; and a LiteDB resume that stays Failed.
- Configured runs (`ASHLAR_ALLOW_MOCK=1`) must complete, including the Hybrid fallback and a resume whose ingest attempt follows the source's.
- The assertions are in `scripts/lib/pipeline_gate_assertions.py` (29 `require()` checks).
- `tests/scripts/pipeline-gate-assertions.test.sh` runs 45 assertions over 10 real-output fixtures plus one-field variants, and is discovered into the required `shell-lint`.
- `.github/workflows/compat-gate.yml` `paths` gains the helper.

**Verified.**
- RED on master `60689412e`: `gate-run-success` returned `"ok":false` with state Failed, exit 2.
- GREEN at `275cce844`: `compat-gate: PASS` and `ship-gate-tier-a: PASS`, seven `pipeline-gate: PASS` legs each.
- With `ASHLAR_ALLOW_MOCK=1` exported, at `7ef40e90d`: `kernel-gate-tier-b: PASS`.
- The agentic placeholder revert: SURVIVED at the old head `94bc4b552`, the gap the review found. KILLED at `7ef40e90d` through both gates (6/8).
- Each of the 29 `require()` checks made vacuous, plus the stage-count relaxation: 30/30 KILLED, green 45/45.
- Branch dispatch 38495511497 at `94bc4b552`: compat-gate success, before the agentic leg.
- Host repo gates: 30 of 32 pass; the 2 known host failures.
- PR CI at `7ef40e90d`: all five required checks and `kernel-gate` pass. shell-lint run 38501123074 reports all 32 gates passed, the new test 45/45.

**Records and docs this PR touches:**
- `CHANGELOG.md` `[Unreleased]`: a new Fixed section, with the #363 → #522 window and the agentic leg.
- `docs/CiGateInventory.md:156`: the compat-gate trigger list gains `scripts/lib/pipeline_gate_assertions.py`.
- `docs/CiGateInventory.md:231`: "one green run each" replaced with counts. dr-gate has 3 master push runs, all green. compat-gate has 4: 2 green, 2 red.
- `docs/production-readiness/KernelReadiness-v1.md:28`: Tier B row, a dated note. It gives the #363 → #522 → #798 window and names #494 as the switch of Production Readiness Gate v1 to fail-closed.
- `docs/production-readiness/ReleaseSignOff-v1.md:73`: the compat row gets a dated note on the second decayed step.
- The header comments of `scripts/kernel-gate-tier-b.sh` and `scripts/ship-gate-tier-a.sh`. The latter no longer claims §3.C.4, or caller-independence beyond `ASHLAR_ALLOW_MOCK`.

**Known residue.** The messages of the first two commits (`a6fd64d10`, `505317fe9`) keep the pre-review window wording; the later commits and the PR body correct it. Issue #797's body also credits #363 with the workflow change; the main thread is correcting #797.

**Found, not fixed (drift).** `docs/ReleaseCandidateChecklist-v1.md:29-33` still lists `gate-run-success.log` and `gate-run-fallback.log` as uploads of `production-readiness-gate-v1`. Since #494 that workflow uploads `gate-run-unconfigured.log` and `gate-run-hooks.log`.

**Possibly stale, not edited.** These describe Tier B's content, not its state: `docs/production-readiness/CompatHardeningPlan-v1.md:12`, `docs/Testing.md:71`, and `docs/production-readiness/KernelChaosDrill-v1.md:20`.
