From: claude
To: grok
Kind: handoff
About: pr-800

SPEC-007 PR 4.8b, the refusal-masking repair, is ready as #800 and is not merged. Branch
`fix/spec007-4.8b-refusal-masking`, head `81f385c93`, on master `b297c98e0`.

It covers review 2026-10-11 BL4, BL5 and M2, then four review rounds on #800:
- B1, S1–S3, N1–N4;
- F1–F3, N1–N5;
- the N2 redo;
- the round at `61bafdea8`.

Cards #802 (workflow stress and optimize) and #803 (workflow agent nodes) hold the code that is recorded here as dated
Known limits.

**What changed**
- **BL4.** `ProviderBackedModel` and `BehaviorExecutor` open a `ProviderRefusalScope` around their availability probe.
  The caller's scope holds the refusal; the factory keeps nothing.
- **BL5, B1, F3.** Five catches rethrow a refusal first, so none answers with echo, canned or pass-through output:
  - `OrchestrationHotSwappableModel`
  - `PlanningAgent`
  - `SynthesisEngine`
  - `ModelBackedMaterialIntelligenceService`
  - `ModelBackedVectorMapIntelligenceService`
- **D23 in `BehaviorExecutor`** (S2, then the N2 redo).
  - A refused probe counts as skipped.
  - When nothing produced output, the step's first refusal is appended as its last error event.
  - It is not appended when the last event written already carried it. The flag is keyed on the written text and
    overwritten on every error event.
  - A refused attempt followed by a failing fallback lists the refusal twice. That is a dated Known limit.
  - D23 holds per step.
- **M2.** The row-24 Warning goes through a 7307 window owned by `ProviderFactory`, which is now `IDisposable`.

**Verified** (container, under the docker lock)
- Red first, five rounds of twins committed alone:
  - `Failed: 12, Passed: 13, Total: 25` at `b582e1179`
  - `Failed: 8, Passed: 14, Total: 22` at `bc34bcdbd`
  - `Failed: 5, Passed: 22, Total: 27` at `d7e053e83`
  - `Failed: 2, Passed: 27, Total: 29` at `065821450`
  - `Failed: 1, Passed: 29, Total: 30` at `83d890016`
- Mutations s66–s81, all 16 at `3bdebf211`: all KILLED, batch verdict KILLED, all restored clean, baseline 30/30.
  Each red hit only its intended twins.
- At `81f385c93`:
  - full cert-gate `Total tests: 3281 / Passed: 3281`, 0 skipped;
  - touched Infrastructure classes `196/196` on net8.0 and on net10.0;
  - `Ashlar.Tests.Orchestration` `310/310`.
- Host repo gates 30 of 32; the 2 failures are the known Windows artefacts.
- KG current at 5165 declared facts.
- Every `spec007-refusal-surfaces.json` `old` string occurs exactly once (81 cases).

**Records and docs it touches, for the drift audit**
- `docs/specs/SPEC-007-security-labels-and-reference-monitor.md`, the PR 4.8 bullet:
  - keeps R3a's "(#743, `6d64ad508`)";
  - gains the "PR 4.8b (#800)" paragraph: the caller's scope, D23 per step with the double listing, the five sites,
    the sweep (17 unfiltered catch-alls and 5 refusal-filtered), the residuals and the IVT pointer.

  The decisions log, its intro and the status table are untouched.
- `docs/EgressInventory.md`, the refusal-section entry "Catch-alls and availability probes (PR 4.8, 4.8b #800)":
  - The corrected sweep. The four handlers the first sweep missed are `AuditingChatClient.cs:64`,
    `ToolCallingAgent.cs:129` and `:315`, and `AshlarA2AAgentHandler.cs:110`. Each comes after a refusal-filtered
    sibling.
  - The per-friend `InternalsVisibleTo` use.
  - Dated Known limits (2026-10-13):
    - status callers;
    - #802;
    - #803;
    - `BehaviorExecutor`'s outer catch, `:364-368` (a throwing outcome recorder at `:291` or semantic cache at `:211`,
      or cancellation, which wins by design);
    - `ProviderFactoryLocalExecutor` with a wrapped refusal, `:56-63`;
    - the double listing in `ExecuteAsync`'s `Errors`;
    - `adapt`/`improve` never flushing the window.
  - Citations: EG-EXE-01 is now `BehaviorExecutor.cs:404-409`, from the `if` to its closing brace, and the
    `ProviderFactory.cs` citations are re-pointed.
- `ci/egress-inventory.tsv`: notes only (`:826`/`:835`).
- `CHANGELOG.md` `[Unreleased]`:
  - `### Fixed — refusal masking (SPEC-007 4.8b)`: D23 per step, the text-keyed rule, the double listing, the outer
    catch, the orchestration consequences and the residuals;
  - `### Changed — a refusal at a brick or cluster node ends a workflow run under FailurePolicy.Continue`, noting that
    agent nodes report success (#803). This is owner question (c).
- `ci/cert-gate-assertions.md`: the `EgressRefusalMaskingTests` row is realigned. The count is 154 `.cs` / 157 entries,
  with #799's history.
- `scripts/mutations/spec007-refusal-surfaces.json`: s66–s81 (65 → 81 cases).
- `docs/knowledge-graph.{json,md}`: regenerated (5150 → 5165 declared facts).

**Not changed, noted**
- `Orchestrator.cs:472` escalates a refused agent as `AgentExecution` (disclosed).
- `spec007-explicit-egress.json` `operator-mode-fault-stays-enforcing`: its `old` occurs twice on master
  (manifest-hygiene lane).
- Follow-ups: D28 windowing at `MeshAutoPullService.cs:366`, `IdeEndpoints.cs:214`, `ImproveCommand.cs:549` and
  `SelfExtendAdmissionBridge.cs:292`.
