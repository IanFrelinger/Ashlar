Task card (`agent-task`; see `_handoff/bus/PROTOCOL.md`). Bus slug: `card-<this number>`. Workstream: **release-0-3-0** (SPEC-007 follow-up). Found by the re-review of PR #800 (4.8b) on 2026-10-14.

**The defect.** After #800, `BehaviorExecutor` keeps a refusal as a step's final error when nothing produced output (D23). The refusal is still lost one level up:
- **The agent node ignores the step error.** `WorkflowExecutor.ExecuteAgentNodeAsync` (`src/.../WorkflowExecutor.cs:246-262` at `daf116cd4`) forwards the events and reads only `BehaviorCompletedEvent.Outputs`. It returns `Success = true`, ignoring every `StepErrorEvent` and `completed.Success`. So an **agent node whose behaviour step was refused reports success**.
- **Brick and cluster nodes do throw the refusal** (`:300-303`, `:391`). Agent nodes are the inconsistent case.
- **The typed refusal is lost at the event boundary.** `StepErrorEvent` carries only `string Error` (`StepErrorEvent.cs:17`), so no consumer can `EgressRefusal.Find` it.
- **Reach:** `BehaviorExecutor`'s only production consumer is `WorkflowExecutor`, DI-registered at `Phases.cs:707-720`. No in-repo code resolves it, so the exposure is SDK hosts that run workflows with agent nodes.

**Done when:**
- `StepErrorEvent` carries the refusal: the exception, or at least its code and ref, in the fixed redacted shape. This is an additive public-API change; record it in the PR, since the tier is Substrate per `docs/SdkCompatibilityPolicy.md`.
- `ExecuteAgentNodeAsync` throws the refusal when the behaviour failed with one, consistent with brick and cluster nodes. Without a refusal, it honours `completed.Success`, or records why not.
- Twins first, red then green: an agent node whose step is refused fails the workflow with the refusal (same ref), and a control without a refusal is unchanged.
- A mutation per behaviour, with verbatim lines.
- Records: the dated Known limit #800 adds to `docs/EgressInventory.md`, the CHANGELOG "a refusal ends a workflow run" note, and SPEC-007's 4.8b paragraph.
- Owner question (c) of the 2026-10-11 review (should `FailurePolicy.Continue` continue past a refused brick?) is related. Ask it if the fix touches the policy.

**Decisions this relies on:** SPEC-007 D23 (a refusal is the final error). It is not an owner row.
