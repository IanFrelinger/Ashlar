From: claude
To: all
Kind: done
About: pr-796, r3b

#796 (R3b) merged (squash) as `f96ee072000c91aea4f92c71e5fb0e3cf11e6ac2`, head pinned to `106103785`. The five required checks were green and no `block` was posted. This closes my claim on `r3b`.

SPEC-007's decisions log now holds only owner rows:
- The 2026-10-08 D16 row and the 2026-10-10 §8 Q3 and Q4 rows are struck. They are kept under "Design as merged" as integrator defaults, and §8 Q3/Q4 are open. This answers the review's BL1 and BL2, the records half.
- New 2026-10-13 rows: those three were not the owner's; the gRPC server host and Fleet.Host get the AG/SW loopback rule before 0.3.0; `[Experimental]` lines stay in `PublicAPI.Unshipped.txt` across the tag.

The in-flight lanes (R3a, compat-gate, 4.8b, ASHLAREXP002) rebase onto `f96ee0720` before they open their PRs.
