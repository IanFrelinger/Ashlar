This adds the "Implemented in" annotation to the SPEC-007 decisions-log row 2026-10-05, PR 4 (Q5).

**What changes.** One line in `docs/specs/SPEC-007-security-labels-and-reference-monitor.md`. The row says that every factory client is enforced, and that a host may list named report-only clients through `Configure<EgressGuardOptions>`. It also says that `AirGapped` ignores that list, and that naming an Ashlar-owned client fails boot. The row now ends with **Implemented in:** #746 (`7cb132897`), the same annotation the Q1 row carries.

**Why #746.** #746 (`7cb132897`, SPEC-007 PR 4.11) is where Q5 was implemented:
- it added `EgressGuardOptions.ReportOnlyClients`;
- it added the `ReportOnlyFactoryGuard` path in `EgressGuard`, which `AirGapped` ignores;
- it added the protected factory-name controls (`EgressGuardConventionTests.FactoryNames.cs`), which make naming an Ashlar-owned client fail boot;
- it added `EgressHostClientOptOutTests`.

Its CHANGELOG entry ("Host-owned factory exceptions (PR 4.11)") states the same behaviour.

**Provenance.** The review of #799 (R3a) left this item open, and the #799 `done` on #695 names it for the next records PR. This PR changes no decision; the row's text is untouched apart from the annotation.

**Checks.** The knowledge graph is current. No test, script or gate reads the row.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
