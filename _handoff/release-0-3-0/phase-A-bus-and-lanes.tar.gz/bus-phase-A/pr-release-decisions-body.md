A records PR. It adds three owner decisions of 2026-10-13 as dated rows in SPEC-007's decisions log, and pointer lines in two docs. No code changes. Under CLAUDE.md these decisions exist only as rows on master, and the 0.3.0 release work depends on them.

## The decisions

| Row | What the owner decided | Owner's words |
|---|---|---|
| Next release | The next release is **0.3.0**. It is the first tag that carries the `AirGapped`/`SecureWorkstation` enforce switch (#746). | "go with 0.3.0 and experimental" |
| PR 1, PR 3a to PR 5 (§4.2) | The unshipped `Ashlar.Abstractions.Security` and `.Security.Egress` surface (150 lines of `PublicAPI.Unshipped.txt`) ships **`[Experimental]`** under a new id, **`ASHLAREXP002`**, with its own constant and policy row. It is applied before the tag. | same message |
| PR 4.10 (#720) | **`AshlarResolvedDeploymentProfileOptions`** (the other 10 unshipped lines) ships `[Experimental]` under `ASHLAREXP002` too. | Answered "Experimental too (Recommended)" when asked separately, because the type is outside `.Security` and the first answer covered "the security API" |

The 150 + 10 split was counted at `4287a18a1`: 160 non-header lines, 150 naming `Ashlar.Abstractions.Security`, 10 naming `AshlarResolvedDeploymentProfileOptions`, and 0 naming neither.

## Pointers

- **SPEC-007 §4.2:** "Decided 2026-10-13", after its "decided before the next tag" sentence.
- **`docs/SdkCompatibilityPolicy.md`, the "This has happened" paragraph:** the open clause becomes the decision. It also says that `ASHLAREXP001` stays the only id until `ASHLAREXP002` is applied, so the "Experimental" section below it remains true.

## Not in this PR: notes for the 0.3.0 release thread

Applying `ASHLAREXP002` is release work. Points for that thread, several from this PR's review:
- **What it needs:**
  - the constant and help URL in a non-experimental holder type, as `AutonomyExperimental` does;
  - a row in the policy's experimental table;
  - `[Experimental]` on the 160 lines' types;
  - an opt-in in every Ashlar project that uses them. About 15 files use `AshlarResolvedDeploymentProfileOptions` alone.
- **Records that name `ASHLAREXP001` as the only id**, true until `ASHLAREXP002` lands: `docs/sdk.md:32` and `docs/SdkCompatibilityPolicy.md:12` and `:88`.
- **The polyfill is already linked** for `Ashlar.Abstractions`' `netstandard2.0` build (`Directory.Build.targets:41-44`). `SdkCompatibilityPolicy.md:96` is stale: it says `Core.Application` compiles it, but `Directory.Build.targets:45-48` removes it there.
- **Opt-in review.** `DiagnosticSuppressionConventionTests` (cert-gate) limits how `ASHLAREXP001` may be suppressed. Decide how `ASHLAREXP002` opt-ins are reviewed, and extend the test with them.
- **Open: promotion.** `RELEASE_RUNBOOK.md` step 7 moves every Unshipped line to `PublicAPI.Shipped.txt`, and `SdkCompatibilityPolicy.md:48` calls a Shipped line "a promise already made". That contradicts the experimental tier (`:82`, `:184`). Decide whether the 160 experimental lines move to `Shipped.txt` at 0.3.0, and how `:48`, `:58` and runbook `:81` read for them.
- **Open: the other packages' SPEC-007 members.** SPEC-007 also added public members outside `Ashlar.Abstractions`, none of them tracked in a PublicAPI file:
  - `AddAshlarEgressGuard`, `EgressGuardOptions`, `LoggerEgressDecisionSink`, `EgressDecisionLoggerSubscription` and `EgressHttpClientBuilderExtensions` in Infrastructure;
  - `AshlarHostingOptions.EgressMode` and `.Clearance` in Hosting;
  - `DataSensitivityLabelBridge` in BackgroundAgents;
  - `TrustTierOrder.RecordLabel`/`CallerLabel` in AI.Pipeline;
  - `PolicyClearances` and `SkillComposition.Decide` in Manifest.

  Some expose types that become experimental. Their tier is **not** decided by these rows. Take it as an integrator decision in the `ASHLAREXP002` PR body, or ask the owner.
- **Left for the drift-746/748 records PR:** the four "Merge pending" cells for #748 (SPEC-007 :24, :447 and the two 2026-10-10 rows). Changing them to "merged" without the drift ask's "library only, no production caller" correction would overstate PR 5.

## Review

An adversarial review (faithfulness, consistency) confirmed the rows match the owner's words and the counts (150 = 63 `.Security` + 87 `.Security.Egress`, plus 10). It also confirmed that #746 is not in v0.2.0, that PR 2 and PR 3b added no Unshipped lines, and that no test asserts these docs' text. Its should-fix, that the log intro claimed a wider scope than the rows, is fixed in the second commit, together with the stale "report-only" wording in the policy paragraph.

## Verified

- `python scripts/ci/verify-compat-policy-current.py`: `compat-policy: current`. It is the shell-lint gate that fails when this policy doc describes a state the repo is not in.
- `bash scripts/check-docs-phantom-paths.sh`: 0 missing. Knowledge graph: current (rebuilding it changed only line endings).
- Line endings unchanged: CRLF, 0 bare LF.

Nothing behavioural changes, so there is nothing to mutation-check.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
