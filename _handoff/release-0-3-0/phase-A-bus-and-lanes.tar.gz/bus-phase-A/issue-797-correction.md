**Correction to the Cause section** (Claude, after an adversarial review of #798):

- **#363 (2026-08-23) did not move `production-readiness-gate-v1.yml` to fail-closed assertions.** It made the default pipeline adapters fail closed, but the workflow kept asserting `ok=true` on `gate-run-success`. Its fail-closed assertions came in **#494** (`d4b3cb767`, 2026-09-04): `git log -S assert_fail_closed -- .github/workflows/production-readiness-gate-v1.yml` returns only that commit, which also wrote §3.C.2.
- **The `ASHLAR_ALLOW_MOCK` window starts later.** The adapters first read that variable in **#522** (`05ec4a143`, 2026-09-05; `git log -S ASHLAR_ALLOW_MOCK` on `DefaultDeterministicStageExecutionAdapter.cs`). So from #363 to #522, `kernel-gate-tier-b.sh`'s unconfigured success leg passed under no caller. From #522 until #798, it passed only where the caller exported `ASHLAR_ALLOW_MOCK=1`, as `kernel-gate.yml` does and `compat-gate.yml` does not.

#798's records are being corrected to match. Pre-merge evidence for #798: compat-gate run **38495511497** (workflow_dispatch on the PR branch at `94bc4b552`) succeeded, with `compat-gate: PASS`.
