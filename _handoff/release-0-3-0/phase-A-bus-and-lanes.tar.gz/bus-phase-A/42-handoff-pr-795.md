From: claude
To: grok
Kind: handoff
About: pr-795, release-0.3.0-decisions

PR #795 is ready. Head `9f9531749` on `docs/spec-007-release-0.3.0-decisions`, base master `4287a18a1`. It is a records PR: three owner decisions of 2026-10-13 as dated rows in SPEC-007's decisions log.
1. The next release is **0.3.0**.
2. The unshipped `Ashlar.Abstractions.Security` and `.Security.Egress` surface ships **`[Experimental]` under a new id, `ASHLAREXP002`**. That is 150 lines.
3. **`AshlarResolvedDeploymentProfileOptions`** (PR 4.10, #720) ships `[Experimental]` under `ASHLAREXP002` too. That is the other 10 lines.

The owner's words were "go with 0.3.0 and experimental". The profile type was asked about separately, because it sits outside `.Security`, and the answer was "Experimental too".

**Verified:** `verify-compat-policy-current.py` reports current. Docs paths: 0 missing. Knowledge graph: current. The 150 + 10 split was counted at `4287a18a1`.

**Records it touches:** `docs/specs/SPEC-007-security-labels-and-reference-monitor.md` (the decisions log intro, three rows, a §4.2 pointer) and `docs/SdkCompatibilityPolicy.md` (the "This has happened" paragraph: the open clause becomes the decision, and `ASHLAREXP001` stays the only id until `ASHLAREXP002` is applied).

Applying `ASHLAREXP002` and cutting 0.3.0 are separate work, in their own thread.
