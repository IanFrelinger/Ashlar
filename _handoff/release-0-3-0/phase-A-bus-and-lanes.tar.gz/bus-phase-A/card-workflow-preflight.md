Task card (`agent-task`; see `_handoff/bus/PROTOCOL.md`). Bus slug: `card-<this number>`. Workstream: **release-0-3-0** (SPEC-007 follow-up). Found by the adversarial review of PR #800 (4.8b) on 2026-10-14.

**The defect.** Under AirGapped/SecureWorkstation enforcement a refused Ollama availability probe never reaches the `workflow` CLI verbs:
- **`ashlar workflow stress` reports ok and exits 0.** `application/src/Ashlar.CLI/Commands/WorkflowCommand.cs:615-618` turns the refused probe into `PreflightResult(false, "Provider unavailable.")`. `StressHandler.cs:153-163` then marks every run `Skipped`, `:287` computes `allPassed = runs.All(r => r.Success || r.Skipped)`, and `:304` returns 0. A run in which nothing ran, because egress was refused, passes.
- **`ashlar workflow optimize` fails closed, but the refusal is lost.** `OptimizeHandler.cs:560` reports "Provider unavailable." with no refusal reference.
- **Why it is not a one-line fix:** `application/` cannot open `ProviderRefusalScope`, which is internal to `Ashlar.Infrastructure` (InternalsVisibleTo grants only test assemblies). So the refusal recorded by `ProviderFactory`'s probe is not reachable from the CLI. Line numbers are at `dbc0d9fb7`; verify on the current tree.

**Done when:**
- A refused probe surfaces as the refusal (the `EgressRefusedException`, with its reference) in both verbs, through a supported API. For example, a public probe on `IProviderFactory` (or a sibling) that returns the refusal alongside availability. Record its public-API and tier implications: Substrate per `docs/SdkCompatibilityPolicy.md`.
- `workflow stress` treats "every run skipped" as not ok, or at least treats a refused probe as a failure. Its exit code follows the CLI's refusal convention: exit 77 per D30 for the verbs that use it, or the documented code otherwise. Record the choice.
- Twins first, red then green, in the container:
  - a refused probe under `workflow stress` gives a non-zero exit and the refusal in the output;
  - the same under `workflow optimize`.
- A mutation per behaviour, with verbatim lines.
- Records: the 4.8b Known limit this card replaces (`docs/EgressInventory.md`, SPEC-007 4.8b paragraph), and the CHANGELOG.
- `[coordinated-integration]` if non-test code changes in both `src/` and `application/`.

**Decisions this relies on:** SPEC-007 D23 (a refusal is the final error, never the echo model) and D30 (CLI exit 77). None are owner rows; if the exit-code convention is in question, ask the owner (review question (b)).
