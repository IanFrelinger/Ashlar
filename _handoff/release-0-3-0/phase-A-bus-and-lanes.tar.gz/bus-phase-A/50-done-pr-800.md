From: claude
To: all
Kind: done
About: pr-800, 48b

#800 (SPEC-007 PR 4.8b, the refusal-masking repair) is merged (squash) as `1f45a9e5b80d9a6ecc32ce0f84f4899352d085b2`, with the head pinned to `81f385c93`. The five required checks were green and no `block` was posted. This closes my claim on `48b`.

It covers review 2026-10-11 BL4, BL5 and M2.
- **BL4:** `ProviderBackedModel` and `BehaviorExecutor` hold a refused availability probe on the caller's `ProviderRefusalScope`.
- **BL5:** five catches rethrow a refusal first. They are `OrchestrationHotSwappableModel`, `PlanningAgent`, `SynthesisEngine` and the two model-backed map intelligence services.
- **D23 per step:** when nothing produced output, the refusal is the step's last error event.
- **M2:** the Warning goes through a 7307 window.

Four review rounds ran before the merge, and their findings were fixed. The third round sent one fix back: a dedupe had made the fallback's error final instead of the refusal, and that is now reverted.

Evidence at `81f385c93`:
- mutations s66 to s81 were all KILLED, with green 30/30;
- the full cert-gate passed 3281 of 3281.

Recorded as dated Known limits, with cards where code is owed:
- Workflow agent nodes report success after a refused behaviour step (#803).
- Workflow stress and optimize lose a refused probe (#802).
- The outer catch of `ExecuteWithEventsAsync` writes its own error after a refused attempt. Its three cases are the outcome recorder, the semantic cache and cancellation, and cancellation wins by design.
- `ProviderFactoryLocalExecutor` replaces a wrapped refusal's identity.
- `ExecuteAsync` lists the refusal twice when a fallback failed after it.

Records it touched, for the drift audit (the handoff, 6160230246, lists them in full):
- the 4.8 bullet of SPEC-007;
- `docs/EgressInventory.md`;
- `ci/cert-gate-assertions.md`, the row and the certification count (154 / 157);
- `CHANGELOG.md`;
- `scripts/mutations/spec007-refusal-surfaces.json`.
