R3b, a records PR. It lands the owner's 2026-10-13 answers to the SPEC-007 review of 2026-10-11 (`REVIEW-2026-10-11.md` on the storage branch `claude/spec-007-pr4-workspace`, §3 and §10) as decisions-log rows, before the code that depends on them (CLAUDE.md, "Decisions land in the log first"). Release 0.3.0, phase A. No code changes.

## The owner's answers (2026-10-13, in the chat)

| Review question | Answer | What changes |
|---|---|---|
| Q-A: did you decide the 2026-10-08 D16 row, the 2026-10-10 §8 Q3 row, the 2026-10-10 §8 Q4 row? | **"None were mine"** | The three rows are deleted from the decisions log and kept under "Design as merged" as integrator defaults with their merge SHAs. The review's §3 STRUCK texts are used, with the D16 row's host-boundary sentence and the Q3 row's per-agent map kept. A 2026-10-13 "Records" row says why. The intro no longer claims "the PR 5 answers of 2026-10-10". §8 Q3 and Q4 stay open, and "§8's six questions are still open" (§8 tail) is true again. |
| Q-C: does the AG/SW loopback-or-fail-boot rule cover the gRPC server host and Fleet.Host? | **"Yes, wire both"** | A 2026-10-13 row. The wiring is release phase B work; until it lands, R3a records it as "not yet wired". |
| (release) What happens to the 160 `[Experimental]` lines at the 0.3.0 promotion? | **"Keep them in Unshipped"** | A 2026-10-13 row; `docs/SdkCompatibilityPolicy.md` "Release step" item 2 and `docs/RELEASE_RUNBOOK.md` step 7 say so. |

Not asked, so not recorded: whether the contradictory 2026-10-10 Q4 "owner" row on the unmerged branch `codex/spec007-clearance-reads` is the owner's. That branch stays unmerged (review §7).

Integrator decision, in the release lane's PR rather than here: SPEC-007's public members in Substrate packages stay Substrate tier per `docs/SdkCompatibilityPolicy.md`. The intro says the owner did not decide their tier.

## Checked

- **BL3's claim on current master:** `git grep -l -E 'SkillComposition\.|SubjectClearance\.|MayCompose|\.HighestLevel|Options\.Clearance|\.Clearance\b' -- src application commercial tools`, excluding tests, matches only `PublicAPI.Unshipped.txt`, `SubjectClearance.cs` and `SkillComposition.cs`. So "No production path reads them yet" in the clearances bullet is true.
- **No record outside SPEC-007 cites the struck rows:** `git grep -i -E 'owner accepted the review recommendation|PR 5 answers|answered 2026-10-10|§8 questions 3 and 4'` over docs, CHANGELOG, CONTINUITY, README, ci and tools returns nothing.
- **Left for R3a (claimed, in flight):** the status table and §5 table "Merge pending" cells (:24, :447), and every other drift item. The two 2026-10-10 rows that also said "Merge pending" are deleted here.

## Verified

- `python scripts/ci/verify-compat-policy-current.py`: `compat-policy: current`.
- `bash scripts/check-docs-phantom-paths.sh`: 0 missing.
- Knowledge graph: current (a rebuild changed only line endings).
- Line endings unchanged (CRLF, 0 bare LF) in all three files.

Records only, so there is nothing to mutation-check.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
