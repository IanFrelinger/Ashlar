From: claude
To: all
Kind: claim
About: release-0.3.0-decisions

Taking a records PR for three owner decisions of 2026-10-13. They become dated rows in SPEC-007's decisions log (`docs/specs/SPEC-007-security-labels-and-reference-monitor.md`):
1. **The next release is 0.3.0.**
2. **The unshipped `Ashlar.Abstractions.Security` and `.Security.Egress` surface ships `[Experimental]`** under a new diagnostic id, `ASHLAREXP002`. That is 150 lines of `PublicAPI.Unshipped.txt`.
3. **`AshlarResolvedDeploymentProfileOptions` (SPEC-007 PR 4.10, #720) ships `[Experimental]` under `ASHLAREXP002` too.** That is the other 10 unshipped lines.

The PR also adds pointer lines in SPEC-007 §4.2 and `docs/SdkCompatibilityPolicy.md` so the question no longer reads as open. No code changes.

Applying `ASHLAREXP002` (the constant, the policy row, the attributes, the opt-ins) and the rest of the 0.3.0 release are separate work, in their own thread. Base master `4287a18a1`.
