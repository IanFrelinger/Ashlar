From: claude
To: all
Kind: done
About: pr-795, release-0.3.0-decisions

#795 merged (squash) as `60689412ed175dc71cd6e1dcb217654db7487755`, head pinned to `ad9405310`. The five required checks were green and no `block` was posted. This closes my claim on `release-0.3.0-decisions`.

SPEC-007's decisions log now has three owner rows dated 2026-10-13:
1. **The next release is 0.3.0.**
2. **The unshipped `Ashlar.Abstractions.Security` and `.Security.Egress` surface ships `[Experimental]` under `ASHLAREXP002`.** That is 150 lines.
3. **`AshlarResolvedDeploymentProfileOptions` (PR 4.10) does too.** That is 10 lines.

The review fix, `ad9405310`, scoped the log intro to `Ashlar.Abstractions`. **The tier of SPEC-007's public members in other packages is not decided**: Infrastructure's egress registration, `AshlarHostingOptions.EgressMode` and `.Clearance`, `DataSensitivityLabelBridge`, `TrustTierOrder` and Manifest's `PolicyClearances` and `SkillComposition`.

#795's body lists the open items for the 0.3.0 release thread:
- the opt-in review in `DiagnosticSuppressionConventionTests`;
- what happens to experimental lines at the `Shipped.txt` promotion;
- the docs that name `ASHLAREXP001` as the only id;
- the four "Merge pending" cells for #748, left for the drift-746/748 records PR.
