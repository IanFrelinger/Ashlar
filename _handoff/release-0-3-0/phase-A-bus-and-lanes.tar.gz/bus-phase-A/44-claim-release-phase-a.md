From: claude
To: all
Kind: claim
About: release-0-3-0, r3b, r3a, drift-746, drift-748, pr-4.8b, compat-gate, ashlarexp002

Starting the 0.3.0 release work. The workstream is `release-0-3-0`, and this is its phase A, pre-release fixes. It takes up SPEC-007 phase H's R3a and PR 4.8b lanes (storage `claude/spec-007-pr4-workspace`, `lane-briefs-phase-G.md`). The owner approved four lanes in parallel.

**The owner's answers of 2026-10-13, landing first as decisions-log rows in R3b:**
- **The three unattested SPEC-007 rows were not the owner's:** 2026-10-08 D16, and 2026-10-10 §8 Q3 and Q4. They are struck to "Design as merged" as integrator defaults, and §8 Q3/Q4 stay open (review Q-A).
- **The gRPC server host and Fleet.Host get the AG/SW loopback-or-fail-boot rule before 0.3.0** (Q-C, card #766). This is phase B work.
- **`[Experimental]` lines stay in `PublicAPI.Unshipped.txt` across the 0.3.0 tag.**

**Claimed, in merge order:**
1. **R3b** (main thread): the rows above. Records only.
2. **R3a** (`docs/spec007-r3a-records-drift`): the review's records drift. Its `done` answers `drift-746` and `drift-748` bullet by bullet.
3. **compat-gate** (`fix/compat-gate-fail-closed-pipeline`): the stale tier-B assertion that has kept compat-gate red since 2026-09-12. An issue opens first.
4. **PR 4.8b** (`fix/spec007-4.8b-refusal-masking`): BL4, BL5 and the D28 windowing. Tests red first; manifest mutations.
5. **ASHLAREXP002** (`feat/ashlarexp002-experimental-security-api`): the id, the attributes on the 160 lines' types, Ashlar's own opt-ins, the convention test and the policy docs.

Each PR gets its own `handoff` and `done`. #750 to #753 are not claimed here.
