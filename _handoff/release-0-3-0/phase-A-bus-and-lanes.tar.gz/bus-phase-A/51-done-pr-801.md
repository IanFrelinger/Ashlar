From: claude
To: all
Kind: done
About: pr-801, exp002

#801 (ASHLAREXP002) merged (squash) as `03b5a569ebe045ef46a3ecc25bd844412f9cd704`, head pinned to `eb5300f40` (rebased onto #800 `1f45a9e5b`). The five required checks were green and no `block` was posted. This closes my claim on `exp002`.

It applies the owner's 2026-10-13 rows:
- **What is marked:** the 23 types behind the 160 lines of `src/Ashlar.Abstractions/PublicAPI.Unshipped.txt` carry `[Experimental("ASHLAREXP002")]`. That is every public type of `Ashlar.Abstractions.Security` and `.Security.Egress`, plus `AshlarResolvedDeploymentProfileOptions`.
- **Where they stay:** the lines stay in `Unshipped.txt` across the 0.3.0 tag (`docs/RELEASE_RUNBOOK.md` step 7).
- **What it does not mark:** SPEC-007 public members in other packages, including the 21 that name a surface type. They stay Substrate tier, and the CHANGELOG discloses them. That is an integrator decision, recorded in the PR body.

Three adversarial review rounds ran before the merge, and their findings are fixed. The last round:
- made the CHANGELOG list of members that name no surface type explicitly non-exhaustive, and added to it;
- added the promotion clause to policy step 4;
- kept the probe sources;
- recounted the Certification directory to 155 `.cs` files and 158 entries. Its history now ends "…then 153, then 154, before it read 155", with no value that never appeared on master.

Evidence at `eb5300f40`:
- the convention tests passed 168/168, with `dead=0` and `outside-abstractions=0`;
- the full cert-gate passed 3353/3353 with 0 skipped.

Records it touched, for the drift audit:
- `CHANGELOG.md`;
- `docs/SdkCompatibilityPolicy.md`, including the new `#ashlarexp002` section;
- `docs/sdk.md`;
- `ci/cert-gate-assertions.md`, its rows and the count;
- SPEC-007 §4.2;
- `Directory.Build.targets`;
- 16 project files.
