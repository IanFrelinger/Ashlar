#!/usr/bin/env bash
# Mutation checks for fix/budgeted-autonomy-pilot-findings, each through scripts/mutation-check.sh against the
# committed SHA. Summary lines are appended to summary.txt; full logs to logs/<id>.log.
#   bash run.sh <sha> [ids...]
set -uo pipefail
REPO="C:/Users/icfre/Documents/Codex/2026-09-12/f-2/work/ashlar-record-correction"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REF="${1:?commit sha}"; shift || true
ONLY=("$@")
export PATH="/c/Users/icfre/AppData/Local/Temp/claude/C--Users-icfre-Documents-Codex-2026-09-12-f-2-work-ashlar-record-correction/56c1a737-9604-4035-910c-22e974a23997/scratchpad/pybin:$PATH"
export ASHLAR_MUTATION_RUNNER="bash tools/autonomy-controller/mutation-runner.sh"
mkdir -p "$HERE/logs"
[[ ${#ONLY[@]} -eq 0 ]] && : > "$HERE/summary.txt"
P=tools/autonomy-controller/ashlar_controller

want() { [[ ${#ONLY[@]} -eq 0 ]] && return 0; local x; for x in "${ONLY[@]}"; do [[ "$x" == "$1" ]] && return 0; done; return 1; }

run() {
  local id="$1" file="$2" old="$3" new="$4"
  want "$id" || return 0
  echo "=== $id" >&2
  ( cd "$REPO" && bash scripts/mutation-check.sh --id "$id" --ref "$REF" --file "$file" --old "$old" --new "$new" ) \
    >"$HERE/logs/$id.log" 2>&1
  grep -E "^mutation $id:" "$HERE/logs/$id.log" | tail -1 >>"$HERE/summary.txt" || echo "mutation $id: NO-SUMMARY (see log)" >>"$HERE/summary.txt"
  tail -1 "$HERE/summary.txt" >&2
}

run f1-resume-clones-afresh "$P/lifecycle.py" \
  '        reused = reusable_workspace(resume_run)
        if reused:' \
  '        reused = reusable_workspace(resume_run)
        if False:'
run f2-empty-workspace-reused "$P/lifecycle.py" \
  '        if not os.listdir(workspace):
            return None' \
  '        if False:
            return None'
run f3-report-prints-merged-twice "$P/metrics.py" \
  '        label = state if outcome == state else f"{state} {outcome or '"'"'-'"'"'}"' \
  '        label = f"{state} {outcome or '"'"'-'"'"'}"'
run f4-resume-passes-no-run "$P/controller.py" \
  '                prepared = self.lifecycle.prepare_implementation(task, run_id, resume_run=resume_run)' \
  '                prepared = self.lifecycle.prepare_implementation(task, run_id, resume_run=None)'

echo "=== done" >&2
cat "$HERE/summary.txt" >&2
