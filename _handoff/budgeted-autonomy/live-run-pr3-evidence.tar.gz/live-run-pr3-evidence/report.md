# Controller ctl-live-pr3

- State: C:/Users/icfre/AppData/Local/Packages/Claude_pzs8sxrjxfjjc/LocalCache/Local/ashlar-controller/state/controller.db
- Policy: 2026-10-11.live-pr3 (13e802f143b0)
- Paused: no
- Disabled providers: claude

## Tasks

### live-pr3

- State: parked-failure (stop reason: pr-closed-unmerged)
- Blocker: PR #775 was closed without a merge at head a84e0e9360c13e9e17700d096e317af81a1cbc47; nothing landed, the task is not done
- Attempts: 2/3 (1 permitted)
- Budget: 4+0 of 16 turns
- Funding pool: claude-subscription
- PR #775 closed closed-unmerged a84e0e9360c1 - rounds 0
- Last run: run-561ad9689fe5 finished completed claude-sonnet-5/medium session 5cc0d1ac-359b-4ed1-86dc-b99762c37b69
- Evidence:
  - archive: -
  - manifest: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\state\runs\run-561ad9689fe5\manifest.json
  - run_dir: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\state\runs\run-561ad9689fe5
  - stderr: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\state\runs\run-561ad9689fe5\stderr.log
  - stdout: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\state\runs\run-561ad9689fe5\stdout.json
  - transcript: C:\Users\icfre\.claude\projects\C--Users-icfre-AppData-Local-Packages-Claude-pzs8sxrjxfjjc-LocalCache-Local-ashlar-controller-state-workspaces-run-561ad9689fe5\5cc0d1ac-359b-4ed1-86dc-b99762c37b69.jsonl
  - workspace: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\state\workspaces\run-561ad9689fe5
  - workspace_present: True

## Metrics

Generated at 2026-10-11T21:38:32Z

### Runs by stop reason

| stop reason | runs |
|---|---|
| completed | 1 |
| transient | 1 |

Runs 2; consumed 4; reserved (active) 0; overshoot 0; attempts used 2

### PRs by outcome

| outcome | prs |
|---|---|
| closed-unmerged | 1 |

PRs 1; open 0; merged 0; closed unmerged 1; repair rounds 0

### Usage (latest per provider and kind)

estimated_api_value is an estimate of API list value, not a charge

| provider | kind | unit | freshness | value | total | observed at |
|---|---|---|---|---|---|---|
| claude | estimated_api_value | usd | fresh | 0.0825114 | - | 2026-10-11T21:27:28Z |
| claude | subscription_allowance | percent | fresh | 32 | 100 | 2026-10-11T21:27:28Z |

Estimated API value by provider (estimate, not a charge): claude 0.0825114

### Retries

Diagnosed failure identities retried: 0; retries total: 0

### Journal by kind

| kind | rows |
|---|---|
| init | 1 |
| launched | 2 |
| lease-acquired | 1 |
| pr-closed-unmerged | 1 |
| pr-observed | 2 |
| pr-opened | 1 |
| pushed | 1 |
| reserved | 2 |
| settled | 2 |
| task-created | 1 |
| task-state | 6 |
| tick-blocked | 2 |
| workspace-prepared | 2 |

Journal rows 24

