# Controller ctl-pilot-pr4

- State: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\controller.db
- Policy: 2026-10-11.pilot-pr4 (2f056e62012f)
- Paused: no
- Disabled providers: none

## Tasks

### pilot-0

- State: done (stop reason: pr-merged)
- Blocker: -
- Attempts: 1/3 (2 permitted)
- Budget: 2+0 of 36 turns
- Funding pool: claude-subscription
- PR #777 merged merged 5483f2b46144 f0fd9d1138e2 rounds 0
- Last run: run-1406fffd9066 finished completed claude-sonnet-5/medium session dae2dfde-12d1-4cff-acc5-2e14afc3cd57
- Evidence:
  - archive: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\evidence\run-1406fffd9066.tar.gz
  - manifest: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-1406fffd9066\manifest.json
  - run_dir: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-1406fffd9066
  - stderr: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-1406fffd9066\stderr.log
  - stdout: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-1406fffd9066\stdout.json
  - transcript: C:\Users\icfre\.claude\projects\C--Users-icfre-AppData-Local-Packages-Claude-pzs8sxrjxfjjc-LocalCache-Local-ashlar-controller-pilot-state-workspaces-run-1406fffd9066\dae2dfde-12d1-4cff-acc5-2e14afc3cd57.jsonl
  - workspace: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\workspaces\run-1406fffd9066
  - workspace_present: True

### pilot-1

- State: done (stop reason: pr-merged)
- Blocker: -
- Attempts: 2/3 (1 permitted)
- Budget: 61+0 of 36 turns
- Funding pool: claude-subscription
- PR #778 merged merged 0cd30c855eb7 ea71db40c792 rounds 0
- Last run: run-3225ebdb59dd finished completed claude-sonnet-5/medium session f37ebd98-4202-43cb-9d86-4fe35fefbc5f
- Evidence:
  - archive: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\evidence\run-3225ebdb59dd.tar.gz
  - manifest: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-3225ebdb59dd\manifest.json
  - run_dir: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-3225ebdb59dd
  - stderr: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-3225ebdb59dd\stderr.log
  - stdout: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-3225ebdb59dd\stdout.json
  - transcript: C:\Users\icfre\.claude\projects\C--Users-icfre-AppData-Local-Packages-Claude-pzs8sxrjxfjjc-LocalCache-Local-ashlar-controller-pilot-state-workspaces-run-f0f6129bc84c\f37ebd98-4202-43cb-9d86-4fe35fefbc5f.jsonl
  - workspace: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\workspaces\run-3225ebdb59dd
  - workspace_present: True

### pilot-2

- State: parked-budget (stop reason: task-budget-exhausted)
- Blocker: task-budget-exhausted: pool pool:pilot-2 has 10 turns left (ceiling 36, consumed 26, reserved 0); an invocation needs 12
- Attempts: 2/3 (1 permitted)
- Budget: 26+0 of 36 turns
- Funding pool: claude-subscription
- Last run: run-f9b0cf0ae47e failed invocation-ceiling-reached claude-sonnet-5/medium session 3180b90f-cd50-4eb2-adcd-ae0e006c9c00
- Evidence:
  - archive: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\evidence\run-f9b0cf0ae47e.tar.gz
  - manifest: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-f9b0cf0ae47e\manifest.json
  - run_dir: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-f9b0cf0ae47e
  - stderr: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-f9b0cf0ae47e\stderr.log
  - stdout: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\runs\run-f9b0cf0ae47e\stdout.json
  - transcript: C:\Users\icfre\.claude\projects\C--Users-icfre-AppData-Local-Packages-Claude-pzs8sxrjxfjjc-LocalCache-Local-ashlar-controller-pilot-state-workspaces-run-e91e25e8ee4a\3180b90f-cd50-4eb2-adcd-ae0e006c9c00.jsonl
  - workspace: C:\Users\icfre\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Local\ashlar-controller\pilot\state\workspaces\run-f9b0cf0ae47e
  - workspace_present: True

## Metrics

Generated at 2026-10-11T23:50:08Z

### Runs by stop reason

| stop reason | runs |
|---|---|
| completed | 2 |
| invocation-ceiling-reached | 3 |

Runs 5; consumed 89; reserved (active) 0; overshoot 39; attempts used 5

### PRs by outcome

| outcome | prs |
|---|---|
| merged | 2 |

PRs 2; open 0; merged 2; closed unmerged 0; repair rounds 0

### Usage (latest per provider and kind)

estimated_api_value is an estimate of API list value, not a charge

| provider | kind | unit | freshness | value | total | observed at |
|---|---|---|---|---|---|---|
| claude | estimated_api_value | usd | fresh | 0.319697 | - | 2026-10-11T23:49:12Z |
| claude | subscription_allowance | percent | fresh | 36 | 100 | 2026-10-11T23:49:12Z |

Estimated API value by provider (estimate, not a charge): claude 7.06417

### Retries

Diagnosed failure identities retried: 0; retries total: 0

### Journal by kind

| kind | rows |
|---|---|
| backup | 1 |
| evidence-archived | 5 |
| init | 1 |
| launched | 5 |
| lease-acquired | 1 |
| pr-merged | 2 |
| pr-observed | 4 |
| pr-opened | 2 |
| pushed | 2 |
| reserved | 5 |
| resume | 2 |
| settled | 5 |
| task-created | 3 |
| task-state | 12 |
| tick-blocked | 4 |
| tick-idle | 2 |
| workspace-prepared | 5 |

Journal rows 61

