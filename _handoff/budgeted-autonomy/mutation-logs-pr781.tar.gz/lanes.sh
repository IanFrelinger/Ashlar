# Sourced by run.sh: lane A (adapters/codex.py) and lane B (adapters/cursor.py) mutations.
A=tools/autonomy-controller/ashlar_controller/adapters

run a1-codex-stdin-left-open "$A/codex.py" \
  '                proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out_f, stderr=err_f, cwd=workspace,' \
  '                proc = subprocess.Popen(argv, stdout=out_f, stderr=err_f, cwd=workspace,'
run a2-codex-model-400-not-recognised "$A/codex.py" \
  '            if code == 400 and _MODEL_UNSUPPORTED_RE.search(text):' \
  '            if False:'
run a3-codex-error-items-charged "$A/codex.py" \
  '            else:
                out["consumed_items"] += 1' \
  '            out["consumed_items"] += 1'
run a4-codex-fresh-run-keeps-mcp "$A/codex.py" \
  '                         "-c", "mcp_servers={}", "-m", request.model, "-o", last_message_path, request.prompt]' \
  '                         "-m", request.model, "-o", last_message_path, request.prompt]'
run a5-codex-resume-inherits-sandbox "$A/codex.py" \
  '                             "-c", f'"'"'sandbox_mode="{self.sandbox}"'"'"', "-c", '"'"'approval_policy="never"'"'"',' \
  '                             "-c", '"'"'approval_policy="never"'"'"','
run a6-codex-hostless-binary-accepted "$A/codex.py" \
  '        return has_code_mode_host(path)
    return True' \
  '        return True
    return True'
run a7-codex-api-key-not-refused "$A/codex.py" \
  '        if env.get("OPENAI_API_KEY"):' \
  '        if False:'

run b1-cursor-logged-out-accepted "$A/cursor.py" \
  '        if proc.returncode != 0 or not text or _NOT_LOGGED_IN_RE.search(text):' \
  '        if proc.returncode != 0 or not text:'
run b2-cursor-turns-charged-zero "$A/cursor.py" \
  '        common: Dict[str, Any] = {"consumed_units": None,' \
  '        common: Dict[str, Any] = {"consumed_units": 0.0,'
run b3-cursor-auth-error-not-classified "$A/cursor.py" \
  '        m = _AUTH_REQUIRED_RE.search(stderr)
        if m:' \
  '        m = _AUTH_REQUIRED_RE.search(stderr)
        if False:'
run b4-cursor-api-key-ignored "$A/cursor.py" \
  '        route = "api-key" if any(env.get(k) for k in API_KEY_VARS) else "cursor-login"' \
  '        route = "cursor-login"'
run b5-cursor-tree-not-killed "$A/cursor.py" \
  'subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"]' \
  'subprocess.run(["taskkill", "/PID", str(pid), "/F"]'
run b6-cursor-empty-stdout-completed "$A/cursor.py" \
  '            if stdout.strip():' \
  '            if True:'

# ---- integration wiring after the cherry-picks
run w1-transcript-codex-branch-dropped "tools/autonomy-controller/ashlar_controller/adapters/__init__.py" \
  '    if manifest.get("provider") == "codex" or manifest.get("sessions_dir"):' \
  '    if False:'
