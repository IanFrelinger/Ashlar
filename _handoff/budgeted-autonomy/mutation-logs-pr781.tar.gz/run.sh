#!/usr/bin/env bash
# Mutation checks for PR 5 (feat/budgeted-autonomy-codex-cursor-adapters), each through scripts/mutation-check.sh
# against the committed SHA. Summary lines are appended to summary.txt; full logs to logs/<id>.log.
#   bash run.sh <sha> [ids...]
set -uo pipefail
REPO="C:/Users/icfre/Documents/Codex/2026-09-12/f-2/work/ashlar-record-correction"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REF="${1:?commit sha}"; shift || true
ONLY=("$@")
export PATH="/c/Users/icfre/AppData/Local/Temp/claude/C--Users-icfre-Documents-Codex-2026-09-12-f-2-work-ashlar-record-correction/56c1a737-9604-4035-910c-22e974a23997/scratchpad/pybin:$PATH"
export ASHLAR_MUTATION_RUNNER="bash tools/autonomy-controller/mutation-runner.sh"
mkdir -p "$HERE/logs"
[[ ${#ONLY[@]} -eq 0 ]] && : > "$HERE/summary.txt"
P=tools/autonomy-controller/ashlar_controller

want() { [[ ${#ONLY[@]} -eq 0 ]] && return 0; local x; for x in "${ONLY[@]}"; do [[ "$x" == "$1" ]] && return 0; done; return 1; }

run() {
  local id="$1" file="$2" old="$3" new="$4"
  want "$id" || return 0
  echo "=== $id" >&2
  ( cd "$REPO" && bash scripts/mutation-check.sh --id "$id" --ref "$REF" --file "$file" --old "$old" --new "$new" ) \
    >"$HERE/logs/$id.log" 2>&1
  grep -E "^mutation $id:" "$HERE/logs/$id.log" | tail -1 >>"$HERE/summary.txt" || echo "mutation $id: NO-SUMMARY (see log)" >>"$HERE/summary.txt"
  tail -1 "$HERE/summary.txt" >&2
}

# ---- the provider transfer (integration)
run t1-transfer-skips-pr-mirror "$P/controller.py" \
  '"UPDATE prs SET provider_transfers_used = provider_transfers_used + 1, updated_at=? WHERE pr_number=?",' \
  '"UPDATE prs SET provider_transfers_used = provider_transfers_used + 0, updated_at=? WHERE pr_number=?",'
run t2-transfer-skips-the-stop "$P/controller.py" \
  '        for run in active:
            # A run that already ended' \
  '        for run in []:
            # A run that already ended'
run t3-transfer-always-cancels "$P/controller.py" \
  '            if status is not None and status.state != RunState.RUNNING:' \
  '            if False:'
run t4-transfer-no-adapter-check "$P/controller.py" \
  '            if self.adapters.get(run["provider"]) is None:' \
  '            if False:'
run t5-transfer-no-reconcile "$P/controller.py" \
  '        if any(r["state"] in RunState.UNCERTAIN for r in active):' \
  '        if False:'
run t6-bound-off-by-one "$P/controller.py" \
  '        if used >= limit:' \
  '        if used > limit:'
run t7-count-per-task-not-pool "$P/controller.py" \
  '        used = self.transfers_used(task["pool_id"])' \
  '        used = int(self.store.row("SELECT COUNT(*) AS n FROM journal WHERE kind='"'"'provider-transferred'"'"' AND task_id=?", (task_id,))["n"])'
run t8-resume-across-providers "$P/controller.py" \
  '                and last["provider"] == task["provider"]):' \
  '                and True):'
run t9-transfer-note-dropped "$P/lifecycle.py" \
  '        handoff = self.handoff_text() + self.transfer_note(task_row, run_id)' \
  '        handoff = self.handoff_text()'
run t10-unit-check-dropped "$P/controller.py" \
  '        if spec["unit"] != pool["unit"]:' \
  '        if False:'
run t11-operator-disable-ignored "$P/controller.py" \
  '        if to_provider in disabled:' \
  '        if False:'
run t12-state-always-queued "$P/controller.py" \
  '        state = TaskState.PR_OPEN if pr is not None else TaskState.QUEUED' \
  '        state = TaskState.QUEUED'
run t13-fake-not-always-registered "$P/cli.py" \
  '    names: List[str] = ["fake"]' \
  '    names: List[str] = []'
run t14-cli-transfer-not-dispatched "$P/cli.py" \
  '        if args.task_cmd == "transfer":' \
  '        if False:'
run t15-metrics-transfers-zero "$P/metrics.py" \
  '            "total": _int(store, "SELECT COUNT(*) FROM journal WHERE kind='"'"'provider-transferred'"'"'"),' \
  '            "total": 0,'

# ---- the adapters (lanes A and B): sourced when present
if [[ -f "$HERE/run-lanes.sh" ]]; then source "$HERE/run-lanes.sh"; fi

echo "=== done" >&2
cat "$HERE/summary.txt" >&2
