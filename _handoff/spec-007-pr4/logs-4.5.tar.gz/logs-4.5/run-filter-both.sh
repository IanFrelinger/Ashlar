set -e
F="FullyQualifiedName~EgressSubject|FullyQualifiedName~EgressGuard|FullyQualifiedName~EgressProducer"
for f in netstandard2.0 net8.0 net10.0; do dotnet build src/Ashlar.Abstractions/Ashlar.Abstractions.csproj -c Debug -f $f --nologo -v minimal 2>&1 | grep -E "Warn|Error|error|warning" | grep -v "SourceLink\|Source control\|src-mirror" || true; echo "== abstractions $f"; done
for t in net8.0 net10.0; do dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj --framework $t --filter "$F" --nologo -v minimal 2>&1 | grep -E "Passed!|Failed!|^\s+Failed |error CS" || true; echo "== filter $t"; done
