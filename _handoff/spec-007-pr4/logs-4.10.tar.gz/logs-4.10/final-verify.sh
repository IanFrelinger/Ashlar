#!/usr/bin/env bash
# Final verification of the 4.10 lane at one committed ref, one container at a time:
#   1. full cert-gate on net8.0 (scripts/run-cert-gate.sh) plus the F6/F8 floors output
#   2. touched classes on net10.0: Infrastructure (AG twin + API prod-style), Ashlar.Tests.CLI (mesh), Mcp.Server.Tests
#   3. build-core: dotnet restore/build Ashlar.LocalDevCore.slnf
#   4. repo gates on the host (no dotnet)
set -uo pipefail
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REPO="$SP/c-4.10"; REF="${1:?ref}"; L="$SP/logs-4.10"
echo "== final-verify at $REF $(date -u +%H:%M:%S) =="
bash "$REPO/scripts/test-in-container.sh" --repo "$REPO" --ref "$REF" -- 'rc=0; bash scripts/run-cert-gate.sh || rc=1; dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj -f net8.0 --no-build --filter "FullyQualifiedName~EgressGuardConventionTests.F6|FullyQualifiedName~EgressGuardConventionTests.F8" --logger "console;verbosity=detailed" || rc=1; exit $rc' > "$L/final-certgate-$REF.log" 2>&1
echo "certgate exit=$? $(date -u +%H:%M:%S)" | tee -a "$L/final-certgate-$REF.log"
bash "$REPO/scripts/test-in-container.sh" --repo "$REPO" --ref "$REF" -- 'rc=0; dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj -f net8.0 --filter "FullyQualifiedName~CapabilityRoutingBrickTests|FullyQualifiedName~MultiSystemNcrSimulationTests|FullyQualifiedName~InfrastructureExecutionGapCoverageTests|FullyQualifiedName~RemoteExecutionSafetyTests|FullyQualifiedName~KernelDiCompositionProdStyleTests|FullyQualifiedName~HostingDeploymentProfileTests|FullyQualifiedName~KernelPhaseResolutionTests|FullyQualifiedName~HostingE2ESmokeTests|FullyQualifiedName~OnboardingE2ETests|FullyQualifiedName~OllamaRemoteLibraryModelArtifactCatalogSourceTests" --nologo -v minimal || rc=1; exit $rc' > "$L/final-net8-neighbours-$REF.log" 2>&1
echo "net8 neighbours exit=$? $(date -u +%H:%M:%S)" | tee -a "$L/final-net8-neighbours-$REF.log"
bash "$REPO/scripts/test-in-container.sh" --repo "$REPO" --ref "$REF" -- 'rc=0; dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj -f net10.0 --filter "FullyQualifiedName~AirGappedHygieneTests|FullyQualifiedName~Tests.VirtualProduction|FullyQualifiedName~CapabilityRoutingBrickTests|FullyQualifiedName~MultiSystemNcrSimulationTests|FullyQualifiedName~InfrastructureExecutionGapCoverageTests|FullyQualifiedName~RemoteExecutionSafetyTests|FullyQualifiedName~KernelDiCompositionProdStyleTests|FullyQualifiedName~HostingDeploymentProfileTests|FullyQualifiedName~KernelPhaseResolutionTests" --nologo -v minimal || rc=1; dotnet test application/src/Ashlar.Tests.CLI/Ashlar.Tests.CLI.csproj --filter "FullyQualifiedName~MeshServeLoopbackProfileTests|FullyQualifiedName~MeshTlsTests|FullyQualifiedName~MeshLanPartyTests|FullyQualifiedName~EgressCliSiteTwinTests" --nologo -v minimal || rc=1; dotnet test src/Ashlar.Mcp.Server.Tests/Ashlar.Mcp.Server.Tests.csproj --nologo -v minimal || rc=1; dotnet test src/Ashlar.Mcp.Client.Tests/Ashlar.Mcp.Client.Tests.csproj --nologo -v minimal || rc=1; exit $rc' > "$L/final-net10-touched-$REF.log" 2>&1
echo "net10 exit=$? $(date -u +%H:%M:%S)" | tee -a "$L/final-net10-touched-$REF.log"
bash "$REPO/scripts/test-in-container.sh" --repo "$REPO" --ref "$REF" -- 'dotnet restore Ashlar.LocalDevCore.slnf && dotnet build Ashlar.LocalDevCore.slnf --no-restore -v minimal' > "$L/final-build-core-$REF.log" 2>&1
echo "build-core exit=$? $(date -u +%H:%M:%S)" | tee -a "$L/final-build-core-$REF.log"
( cd "$REPO" && PATH=$SP/sc-py/bin:$PATH bash scripts/ci/run-repo-gates.sh ) > "$L/final-repo-gates-$REF.log" 2>&1
echo "repo-gates exit=$? $(date -u +%H:%M:%S)" | tee -a "$L/final-repo-gates-$REF.log"
echo "== final-verify done $(date -u +%H:%M:%S) =="
