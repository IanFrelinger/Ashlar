import os
SP='/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad'
ABS='src/Ashlar.Abstractions/Security/Egress/'
CLS="FullyQualifiedName~EgressRedirectTwinTests|FullyQualifiedName~EgressRedirectDifferentialTests|FullyQualifiedName~EgressHttpNetstandard20TwinTests|FullyQualifiedName~EgressHttpHandlerTwinTests|FullyQualifiedName~EgressFactoryDefaultsTwinTests"
# (id, file, old, new, filter, framework, project)
muts=[
 ('m1-per-authority-decision-dropped', ABS+'EgressHopEvaluation.cs',
  'if (note.Authority is not null && string.Equals(note.Authority, AuthorityOf(uri), StringComparison.Ordinal))',
  'if (note.Authority is not null)', CLS, None, None),
 ('m2-egresshttp-installs-no-follower', ABS+'EgressHttp.cs',
  'var followed = EgressRedirectHandler.Install(inner, followsAcrossOrigins: false, family, site, guard);',
  'var followed = inner;', CLS, None, None),
 ('m3-factory-filter-installs-no-follower', 'src/Ashlar.Infrastructure/Egress/EgressRedirectFilter.cs',
  'builder.PrimaryHandler = EgressRedirectHandler.Install(primary,', '_ = EgressRedirectHandler.Install(primary,', CLS, None, None),
 ('m4-guard-handler-not-restored', 'src/Ashlar.Infrastructure/Egress/EgressRedirectFilter.cs',
  'if (!builder.AdditionalHandlers.Any(handler => handler is EgressGuardHandler))', 'if (builder.AdditionalHandlers.Count < 0)', CLS, None, None),
 ('m5-p2-cross-origin-followed', ABS+'EgressRedirectHandler.cs',
  'if (!FollowsAcrossOrigins && !SameOrigin(requestUri, location))', 'if (!FollowsAcrossOrigins && !SameOrigin(requestUri, location) && hops < 0)', CLS, None, None),
 ('m6-https-to-http-followed', ABS+'EgressRedirectHandler.cs',
  'if (!toHttps && IsSecure(requestUri.Scheme))', 'if (!toHttps && IsSecure(location.Scheme))', CLS, None, None),
 ('m7-authorization-not-cleared', ABS+'EgressRedirectHandler.cs',
  '        request.Headers.Authorization = null;\n', '', CLS, None, None),
 ('m8-post-send-check-dropped-async', ABS+'EgressGuardHandler.cs',
  '        var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);\n        EgressHopEvaluation.CheckAfterSend(request, response);\n',
  '        var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);\n', CLS, None, None),
 ('m9-original-setting-forgotten', ABS+'EgressRedirectHandler.cs',
  'if (Originals.TryGetValue(primary, out var known))', 'if (Originals.TryGetValue(primary, out var known) && known.MaxRedirects < 0)', CLS, None, None),
 ('m10-method-rewrite-dropped', ABS+'EgressRedirectHandler.cs',
  '300 or 301 or 302 => method == HttpMethod.Post,', '300 or 301 or 302 => false,', CLS, None, None),
 ('m11-walker-stops-at-the-hop', ABS+'EgressRedirectHandler.cs',
  '                underHop = true;\n                current = hop.Inner;\n', '                underHop = true;\n                current = hop;\n',
  'FullyQualifiedName~EgressHttpNetstandard20TwinTests', None, None),
 ('m12-credentials-ignored', ABS+'EgressRedirectHandler.cs',
  'case HttpClientHandler client when client.Credentials is null || client.Credentials is CredentialCache:', 'case HttpClientHandler client:', CLS, None, None),
 ('m13-api-sns-follows', 'application/src/Ashlar.API/Program.cs',
  'c => c.Timeout = TimeSpan.FromSeconds(15)).NeverFollowRedirects();', 'c => c.Timeout = TimeSpan.FromSeconds(15));',
  'FullyQualifiedName~EgressApiHostProdStyleTests', 'net10.0', None),
 ('m14-fleet-sns-follows', 'commercial/src/Ashlar.Commercial.Fleet.Host/Program.cs',
  'c => c.Timeout = TimeSpan.FromSeconds(15)).NeverFollowRedirects();', 'c => c.Timeout = TimeSpan.FromSeconds(15));',
  'FullyQualifiedName~EgressFleetHostTwinTests', 'net10.0', 'commercial/tests/Ashlar.Commercial.Tests.Fleet.Host/Ashlar.Commercial.Tests.Fleet.Host.csproj'),
 ('m15-bedrock-follows', 'src/Ashlar.AI.Pipeline/Clients/AwsBedrockChatClientFactory.cs',
  'var config = new AmazonBedrockRuntimeConfig { AllowAutoRedirect = false };', 'var config = new AmazonBedrockRuntimeConfig { AllowAutoRedirect = true };',
  'FullyQualifiedName~EgressGuardChatClientTwinTests', None, None),
 ('m17-unknown-primary-warning-inverted', 'src/Ashlar.Infrastructure/Egress/EgressRedirectFilter.cs',
  '        if (!enforcing)\n            return;\n', '        if (enforcing)\n            return;\n', CLS, None, None),
 ('m18-redirect-limit-off-by-one', ABS+'EgressRedirectHandler.cs',
  'if (++hops > MaxRedirects)', 'if (++hops > MaxRedirects + 1)', CLS, None, None),
 ('m19-no-note-treated-as-decided', ABS+'EgressHopEvaluation.cs',
  '            Store(request, note);\n        }\n\n        if (note.Authority is not null',
  '            Store(request, note);\n            return false;\n        }\n\n        if (note.Authority is not null', CLS, None, None),
 ('m20-hop-decided-by-process-default', ABS+'EgressHopEvaluation.cs',
  '_ = (Guard ?? EgressGuard.ProcessDefault).Evaluate(egress);', '_ = EgressGuard.ProcessDefault.Evaluate(egress);', CLS, None, None),
 ('m21-started-primary-as-if-flipped', ABS+'EgressRedirectHandler.cs',
  '                // It has sent, or been disposed, so its setting is fixed: it keeps following on its own.\n                return (false, RuntimeDefaultMaxRedirects);\n',
  '                // It has sent, or been disposed, so its setting is fixed: it keeps following on its own.\n                return (true, RuntimeDefaultMaxRedirects);\n', CLS, None, None),
 ('m22-known-primary-by-exact-type', ABS+'EgressRedirectHandler.cs',
  'case HttpClientHandler client when client.Credentials is null || client.Credentials is CredentialCache:',
  'case HttpClientHandler client when client.GetType() == typeof(HttpClientHandler) && (client.Credentials is null || client.Credentials is CredentialCache):', CLS, None, None),
 ('m23-composite-primary-skipped', 'src/Ashlar.Infrastructure/Egress/EgressRedirectFilter.cs',
  '        builder.PrimaryHandler = EgressRedirectHandler.Install(primary, followsAcrossOrigins: true, EgressFamilies.HttpFactory, site, guard);\n',
  '        if (primary is HttpClientHandler or SocketsHttpHandler)\n            builder.PrimaryHandler = EgressRedirectHandler.Install(primary, followsAcrossOrigins: true, EgressFamilies.HttpFactory, site, guard);\n', CLS, None, None),
 ('m24-cancellation-between-hops-ignored', ABS+'EgressRedirectHandler.cs',
  '        if (cancellationToken.IsCancellationRequested)\n        {\n            response.Dispose();\n            cancellationToken.ThrowIfCancellationRequested();\n        }\n\n',
  '', CLS, None, None),
 ('m25-intermediate-response-not-disposed', ABS+'EgressRedirectHandler.cs',
  '        var status = (int)response.StatusCode;\n        response.Dispose();\n',
  '        var status = (int)response.StatusCode;\n', CLS, None, None),
 ('m26-follower-follows-into-the-host-boundary', ABS+'EgressRedirectHandler.cs',
  '        if (!InsideHostBoundary(requestUri) && InsideHostBoundary(location))\n',
  '        if (false && !InsideHostBoundary(requestUri) && InsideHostBoundary(location))\n', CLS, None, None),
]
os.makedirs('t', exist_ok=True)
for f in os.listdir('t'):
    os.remove(os.path.join('t', f))
batches = {'a': muts[0:8], 'b': muts[8:16], 'c': muts[16:21], 'd': muts[21:]}
for batch, sel in batches.items():
    lines=['#!/usr/bin/env bash','set -u',f'cd {SP}/c-4.3']
    for (i,f,o,n,flt,fw,proj) in sel:
        open(f't/{i}.old','w').write(o); open(f't/{i}.new','w').write(n)
        args=f'--id {i} --file {f} --old-file {SP}/mut/t/{i}.old --new-file {SP}/mut/t/{i}.new --filter "{flt}"'
        if fw: args+=f' --framework {fw}'
        if proj: args+=f' --project {proj}'
        lines.append(f'bash scripts/mutation-check.sh --repo {SP}/c-4.3 {args} > {SP}/logs-4.3/mut-{i}.log 2>&1; tail -1 {SP}/logs-4.3/mut-{i}.log >> {SP}/logs-4.3/mutations-summary.txt')
    lines.append(f'echo "BATCH-{batch} DONE" >> {SP}/logs-4.3/mutations-summary.txt')
    open(f'batch-{batch}.sh','w').write('\n'.join(lines)+'\n')
print('ok', len(muts), {k: len(v) for k, v in batches.items()})
