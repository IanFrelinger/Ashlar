#!/usr/bin/env bash
# Runs batches B, C and D of the 4.10 mutation checks at one ref, one container at a time.
set -uo pipefail
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REF="${1:?ref}"
bash $SP/mut-4.10/run-batch-2.sh B "$REF"
bash $SP/mut-4.10/run-batch-2.sh C "$REF"
bash $SP/mut-4.10/run-batch-3.sh "$REF"
echo "== run-all done $(date -u +%H:%M:%S) =="
