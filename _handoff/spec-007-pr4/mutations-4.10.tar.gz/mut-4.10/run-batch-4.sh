#!/usr/bin/env bash
# Batch E: mutants for the literal-Q6 mesh serve and the profile-read convention. Usage: run-batch-4.sh <ref>
set -uo pipefail
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REPO="$SP/c-4.10"; MUT="$SP/mut-4.10"; REF="${1:?ref}"
INFRA=src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj
CLI=application/src/Ashlar.Tests.CLI/Ashlar.Tests.CLI.csproj
AG='FullyQualifiedName~AirGappedHygieneTests'
MESH='FullyQualifiedName~MeshServeLoopbackProfileTests'
run() {
  local id="$1" file="$2" project="$3" fw="$4" filter="$5"; shift 5
  local wd="$MUT/$id"
  if [[ -e "$wd" ]]; then echo "== skip $id: work dir exists =="; return; fi
  echo "== $(date -u +%H:%M:%S) start $id =="
  bash "$REPO/scripts/mutation-check.sh" --repo "$REPO" --ref "$REF" --id "$id" --file "$file" \
    --project "$project" --framework "$fw" --filter "$filter" --work-dir "$wd" --keep "$@" > "$MUT/$id.log" 2>&1
  local rc=$?
  local summary; summary="$(grep -E "^mutation ${id}: " "$MUT/$id.log" | tail -1)"
  echo "$(date -u +%H:%M:%S) rc=$rc ${summary:-NO-SUMMARY-LINE}" | tee -a "$MUT/SUMMARY.txt"
}
run mesh-anyip application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$CLI" net10.0 "$MESH" \
  --old 'k.ListenLocalhost(_settings.Port, configure);' --new 'k.ListenAnyIP(_settings.Port, configure);'
run mesh-bindaddress application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$CLI" net10.0 "$MESH" \
  --old 'return BindsLoopbackOnly(profile) ? $"{scheme}://localhost:{settings.Port}" : $"{scheme}://*:{settings.Port}";' --new 'return $"{scheme}://*:{settings.Port}";'
run mesh-anyip-certgate application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$INFRA" net8.0 "$AG" \
  --old 'k.ListenLocalhost(_settings.Port, configure);' --new 'k.ListenAnyIP(_settings.Port, configure);'
run profile-read-convention src/Ashlar.Infrastructure/Deployment/ResolvedDeploymentProfile.cs "$INFRA" net8.0 'FullyQualifiedName~DeploymentProfileReadConventionTests' \
  --old 'Profile = profile.Trim();' --new 'Profile = profile.Trim(); _ = "ASHLAR_DEPLOYMENT_PROFILE";'
run api-prebind-certgate-r2 application/src/Ashlar.API/Program.cs "$INFRA" net8.0 "$AG" \
  --old 'throw new InvalidOperationException(listenerViolation);' --new '_ = listenerViolation;'
echo "== batch E done $(date -u +%H:%M:%S) =="
