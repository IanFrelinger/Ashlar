#!/usr/bin/env bash
# Runs the 4.10 mutation checks of ONE batch sequentially (one container at a time), keeping each work dir,
# appending every summary line verbatim to SUMMARY.txt. Usage: run-batch.sh <batch-name> <ref>
set -uo pipefail
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REPO="$SP/c-4.10"
MUT="$SP/mut-4.10"
BATCH="${1:?batch}"; REF="${2:?ref}"
INFRA=src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj
CLI=application/src/Ashlar.Tests.CLI/Ashlar.Tests.CLI.csproj
AG='FullyQualifiedName~AirGappedHygieneTests'
API='FullyQualifiedName~AirGappedProfileApiHostProdStyleTests'
MESH='FullyQualifiedName~MeshServeLoopbackProfileTests'

run() { # id file project framework filter -- then --old/--new args
  local id="$1" file="$2" project="$3" fw="$4" filter="$5"; shift 5
  local wd="$MUT/$id"
  if [[ -e "$wd" ]]; then echo "== skip $id: work dir exists =="; return; fi
  echo "== $(date -u +%H:%M:%S) start $id =="
  bash "$REPO/scripts/mutation-check.sh" --repo "$REPO" --ref "$REF" --id "$id" --file "$file" \
    --project "$project" --framework "$fw" --filter "$filter" --work-dir "$wd" --keep "$@" > "$MUT/$id.log" 2>&1
  local rc=$?
  local summary; summary="$(grep -E "^mutation ${id}: " "$MUT/$id.log" | tail -1)"
  echo "$(date -u +%H:%M:%S) rc=$rc ${summary:-NO-SUMMARY-LINE}" | tee -a "$MUT/SUMMARY.txt"
}

case "$BATCH" in
  A)
    run router-ag-local src/Ashlar.Infrastructure/Execution/Routing/NcrCapabilityRouter.cs "$INFRA" net8.0 "$AG" \
      --old '_airGapped = deploymentProfile?.IsAirGapped == true;' --new '_airGapped = false;'
    run adaptive-candidates src/Ashlar.Infrastructure/Execution/AdaptiveProviderFactory.cs "$INFRA" net8.0 "$AG" \
      --old '_airGapped ? candidates.Where(p => !IsCloudProvider(p)).ToArray() : candidates;' --new 'candidates;'
    run d5-strictest src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'new ResolvedDeploymentProfile(AshlarDeploymentProfileEnvironment.ResolvedRaw ?? profile);' --new 'new ResolvedDeploymentProfile(profile);'
    run mcp-sw-http src/Ashlar.Mcp.Server/ValidateAshlarMcpServerOptions.cs "$INFRA" net8.0 "$AG" \
      --old 'IsSecureWorkstation(profile) && ServesOverHttp())' --new 'IsSecureWorkstation(profile) && !ServesOverHttp())'
    run loopback-ip src/Ashlar.Infrastructure/Deployment/LoopbackListenerPolicy.cs "$INFRA" net8.0 "$AG" \
      --old 'return IPAddress.TryParse(host, out var ip) && IPAddress.IsLoopback(ip);' --new 'return IPAddress.TryParse(host, out _);'
    run validator-runpod src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'return Refuse(options.EnablePeerNetworkRouting,' --new 'return Refuse(!options.EnablePeerNetworkRouting,'
    run validator-bedrock src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'return Refuse(bedrock,' --new 'return Refuse(!bedrock,'
    run validator-brickhost src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'return Refuse(remote,' --new 'return Refuse(!remote,'
    ;;
  B)
    run validator-meshlab src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'return Refuse(options.Enabled,' --new 'return Refuse(!options.Enabled,'
    run ollama-default src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
      --old 'static o => o.Enabled = false' --new 'static o => o.Enabled = true'
    run router-peer-refusal src/Ashlar.Infrastructure/Execution/Routing/NcrCapabilityRouter.cs "$INFRA" net8.0 "$AG" \
      --old 'throw new InvalidOperationException(refused);' --new '_ = refused;'
    run adaptive-multiframe src/Ashlar.Infrastructure/Execution/AdaptiveProviderFactory.cs "$INFRA" net8.0 "$AG" \
      --old 'if (_airGapped && IsCloudProvider(resolved))' --new 'if (_airGapped && !IsCloudProvider(resolved))'
    run loopback-http-ports src/Ashlar.Infrastructure/Deployment/LoopbackListenerPolicy.cs "$INFRA" net8.0 "$AG" \
      --old 'addresses.AddRange(Split(configuration["http_ports"]).Select(port => $"http://*:{port}"));' --new ''
    run loopback-profile src/Ashlar.Infrastructure/Deployment/LoopbackListenerPolicy.cs "$INFRA" net8.0 "$AG" \
      --old 'if (profile is not { RequiresLoopbackInbound: true })' --new 'if (profile is null)'
    ;;
  C)
    run api-prebind application/src/Ashlar.API/Program.cs "$INFRA" net10.0 "$API" \
      --old 'throw new InvalidOperationException(listenerViolation);' --new '_ = listenerViolation;'
    run api-verifier application/src/Ashlar.API/Security/LoopbackListenerVerifier.cs "$INFRA" net10.0 "$API" \
      --old 'return violation is null ? Task.CompletedTask : throw new InvalidOperationException(violation);' --new 'return Task.CompletedTask;'
    run mesh-return application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$CLI" net10.0 "$MESH" \
      --old-file "$MUT/mesh-return.old" --new-file "$MUT/mesh-return.new"
    run mesh-address application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$CLI" net10.0 "$MESH" \
      --old '://*:{settings.Port}' --new '://localhost:{settings.Port}'
    ;;
  *) echo "unknown batch $BATCH"; exit 2 ;;
esac
echo "== batch $BATCH done $(date -u +%H:%M:%S) =="
