#!/usr/bin/env python3
"""Builds the mutation table rows (id, summary line, red test names) from the kept logs."""
import glob, os, re, sys
MUT = '/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad/mut-4.10'
rows = []
for log in sorted(glob.glob(os.path.join(MUT, '*.log'))):
    name = os.path.basename(log)[:-4]
    if name.startswith('batch-'):
        continue
    text = open(log, encoding='utf-8', errors='replace').read()
    summ = [l for l in text.splitlines() if l.startswith(f'mutation {name}: ')]
    summary = summ[-1] if summ else 'NO SUMMARY LINE'
    # red run failing tests: the "  Failed <fqn>" lines before "porcelain="
    red_part = text.split('porcelain=')[0]
    reds = re.findall(r'^\s+Failed (\S+?)(?:\((.*?)\))? \[', red_part, flags=re.M)
    names = []
    for fqn, args in reds:
        short = fqn.split('.')[-1]
        names.append(short + (f'({args})' if args else ''))
    applied = re.search(r'^replaced 1 occurrence in (.+?) at line (\d+)', text, flags=re.M)
    rows.append((name, summary, applied.group(1) if applied else '?', applied.group(2) if applied else '?', names))
for name, summary, f, ln, names in rows:
    print(f'### {name}  ({f}:{ln})')
    print(summary)
    for n in names:
        print(f'  - {n}')
    print()
