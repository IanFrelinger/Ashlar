#!/usr/bin/env bash
# Batch D: mutants for the behaviour added after the scouts' lists (one container at a time). Usage: run-batch-3.sh <ref>
set -uo pipefail
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REPO="$SP/c-4.10"; MUT="$SP/mut-4.10"; REF="${1:?ref}"
INFRA=src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj
AG='FullyQualifiedName~AirGappedHygieneTests'
run() {
  local id="$1" file="$2" project="$3" fw="$4" filter="$5"; shift 5
  local wd="$MUT/$id"
  if [[ -e "$wd" ]]; then echo "== skip $id: work dir exists =="; return; fi
  echo "== $(date -u +%H:%M:%S) start $id =="
  bash "$REPO/scripts/mutation-check.sh" --repo "$REPO" --ref "$REF" --id "$id" --file "$file" \
    --project "$project" --framework "$fw" --filter "$filter" --work-dir "$wd" --keep "$@" > "$MUT/$id.log" 2>&1
  local rc=$?
  local summary; summary="$(grep -E "^mutation ${id}: " "$MUT/$id.log" | tail -1)"
  echo "$(date -u +%H:%M:%S) rc=$rc ${summary:-NO-SUMMARY-LINE}" | tee -a "$MUT/SUMMARY.txt"
}
run bedrock-composition src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
  --old 'if (!resolved.IsAirGapped)' --new 'if (resolved.IsAirGapped)'
run validator-bedrock-r2 src/Ashlar.Hosting/AshlarServiceCollectionExtensions.AirGapped.cs "$INFRA" net8.0 "$AG" \
  --old 'return bedrock && _profile.IsAirGapped ?' --new 'return !bedrock && _profile.IsAirGapped ?'
run router-overnight-only src/Ashlar.Infrastructure/Execution/Routing/NcrCapabilityRouter.cs "$INFRA" net8.0 "$AG" \
  --old 'if (_airGapped)' --new 'if (_airGapped && requirements.IsOvernightOrBackground)'
run mcp-marker-name src/Ashlar.Mcp.Server/ValidateAshlarMcpServerOptions.cs "$INFRA" net8.0 "$AG" \
  --old '"ModelContextProtocol.AspNetCore.StreamableHttpHandler, ModelContextProtocol.AspNetCore";' --new '"ModelContextProtocol.AspNetCore.NoSuchHandler, ModelContextProtocol.AspNetCore";'
run api-prebind-certgate application/src/Ashlar.API/Program.cs "$INFRA" net8.0 "$AG" \
  --old 'throw new InvalidOperationException(listenerViolation);' --new '_ = listenerViolation;'
run mesh-return-certgate application/src/Ashlar.CLI/Commands/BackgroundAgent/MeshServeService.cs "$INFRA" net8.0 "$AG" \
  --old-file "$MUT/mesh-return.old" --new-file "$MUT/mesh-return.new"
run collection-attribute src/Ashlar.Tests.Infrastructure/Tests/Certification/AirGappedHygieneTests.cs "$INFRA" net8.0 'FullyQualifiedName~ProcessGlobalEnvironmentConventionTests' \
  --old-file "$MUT/collection.old" --new-file "$MUT/collection.new"
echo "== batch D done $(date -u +%H:%M:%S) =="
