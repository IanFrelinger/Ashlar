#!/usr/bin/env bash
# Runs the lane's mutation checks in sequence (one container at a time), each with scripts/mutation-check.sh on the
# committed head, logging each run and appending its verbatim summary line to SUMMARY.txt.
# usage: run-mutations.sh <ref> <id>...   (ids from the table below)
set -u
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad
REPO=$SP/c-4.5; M=$SP/mut-4.5; REF=$1; shift
F='FullyQualifiedName~EgressSubject|FullyQualifiedName~EgressGuard|FullyQualifiedName~EgressProducer'
ES=src/Ashlar.Abstractions/Security/Egress/EgressSubject.cs
TCA=src/Ashlar.BackgroundAgents/Agents/ToolCallingAgent.cs
RAG=src/Ashlar.BackgroundAgents/RAG/RAGTool.cs
EGC=src/Ashlar.AI.Pipeline/Governance/EgressGuardChatClient.cs
SX=src/Ashlar.BackgroundAgents.HostRunners/SelfExtendRunnerAdapter.cs
run() { # id file old-args...
  local id=$1 file=$2; shift 2
  local wd=$M/work-$id; rm -rf "$wd"
  echo "=== $id ($(date -u +%H:%M:%S))"
  bash "$REPO/scripts/mutation-check.sh" --id "$id" --repo "$REPO" --ref "$REF" --file "$file" --filter "$F" --framework net8.0 --work-dir "$wd" "$@" > "$M/$id.log" 2>&1
  echo "exit=$?" >> "$M/$id.log"
  grep -E '^mutation ' "$M/$id.log" | tail -1 | tee -a "$M/SUMMARY.txt"
  echo "--- red failing tests:" ; grep -E '^\s+Failed ' "$M/$id.log" | sed 's/ \[.*//' | sort -u | head -60
}
for id in "$@"; do case $id in
  m01-begin-read-does-not-enter-the-reads-frame) run $id $ES --old '        Active.Value = read;' --new '' ;;
  m02-live-does-not-skip-a-reads-frame)          run $id $ES --old '(frame.IsDisposed || frame._isRead)' --new 'frame.IsDisposed' ;;
  m03-a-reads-frame-observes-outward-on-dispose) run $id $ES --old 'if (Mark is not null && !_isRead)' --new 'if (Mark is not null)' ;;
  m04-agent-completes-the-read-before-invoking)  run $id $TCA --old-file $M/m04.old --new-file $M/m04.new ;;
  m05-agent-never-hands-the-scope-to-a-labelled-tool) run $id $TCA --old-file $M/m05.old --new-file $M/m05.new ;;
  m06-ragtool-does-not-report-its-hits)          run $id $RAG --old '                read.Report(HitLabel(_sensitivityRegistry, hit.SensitivityLevelName));' --new '                _ = HitLabel(_sensitivityRegistry, hit.SensitivityLevelName);' ;;
  m07-ragtool-maps-an-unknown-tier-to-public)    run $id $RAG --old '            : SecurityLabel.SystemHigh;' --new '            : SecurityLabel.Public;' ;;
  m08-ragtool-does-not-trim)                     run $id $RAG --old '        var trimmed = tier.Trim();' --new '        var trimmed = tier;' ;;
  m09-ragtool-maps-a-custom-level)               run $id $RAG --old 'level is not null && DataSensitivityLevels.All.Any(canonical => ReferenceEquals(canonical, level))' --new 'level is not null' ;;
  m10-ragtool-refusal-is-not-read-nothing)       run $id $RAG --old '            read?.Report(SecurityLabel.Public);' --new '' ;;
  m11-ragtool-no-hits-is-not-read-nothing)       run $id $RAG --old '            read.Report(SecurityLabel.Public);' --new '' ;;
  m12-no-target-is-agent-backed)                 run $id $EGC --old-file $M/m12.old --new-file $M/m12.new ;;
  m13-streamed-response-observed-only-at-the-end) run $id $EGC --old-file $M/m13.old --new-file $M/m13.new ;;
  m14-self-extend-enters-no-frame)               run $id $SX --old '        using var subject = EgressSubject.Enter("agent:" + resolvedAgentId, new HighWaterMark(SecurityLabel.SystemHigh));' --new '' ;;
  m15-self-extend-floor-public)                  run $id $SX --old 'new HighWaterMark(SecurityLabel.SystemHigh));' --new 'new HighWaterMark(SecurityLabel.Public));' ;;
  m16-self-extend-frame-not-a-using)             run $id $SX --old '        using var subject = EgressSubject.Enter(' --new '        var subject = EgressSubject.Enter(' ;;
  m17-every-target-is-agent-backed)              run $id $EGC --old-file $M/m12.old --new-file $M/m17.new ;;
  m18-stream-end-not-observed)                   run $id $EGC --old-file $M/m18.old --new-file $M/m18.new ;;
  m19-response-end-not-observed)                 run $id $EGC --old-file $M/m19.old --new-file $M/m19.new ;;
  m20-synchronous-throw-not-observed-on-the-response-route) run $id $EGC --old-file $M/m20.old --new-file $M/m20.new ;;
  m21-synchronous-throw-not-observed-on-the-stream-route)   run $id $EGC --old-file $M/m21.old --new-file $M/m21.new ;;
  m22-a-production-tool-declares-itself-labelled) run $id src/Ashlar.Tools.Dev/RepoFsReadTool.cs --old-file $M/m22.old --new-file $M/m22.new ;;
  m23-ragtool-reads-nothing-for-every-ArgumentException) run $id $RAG --old-file $M/m23.old --new-file $M/m23.new ;;
  m24-ragtool-drops-the-canonical-spelling-check) run $id $RAG --old-file $M/m24.old --new-file $M/m24.new ;;
  m25-a-using-alias-of-EgressSubject-in-production) run $id src/Ashlar.BackgroundAgents.HostRunners/PlannerScratchpad.cs --old-file $M/m25.old --new-file $M/m25.new ;;
  m26-a-report-completes-the-read)               run $id src/Ashlar.Abstractions/Security/Egress/ReadReporter.cs --old-file $M/m26.old --new-file $M/m26.new ;;
  *) echo "unknown id $id";;
esac; done
echo "=== batch done ($(date -u +%H:%M:%S))"
