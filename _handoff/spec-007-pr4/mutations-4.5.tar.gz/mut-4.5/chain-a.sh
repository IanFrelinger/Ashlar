#!/usr/bin/env bash
# Chain A: (1) the twins alone on the pre-fix RAGTool/VectorMath (red expected), (2) Abstractions builds + the egress
# filter on net8.0 and net10.0 at t-all (green required). Stops after (1) if (2)'s tree does not compile.
set -u
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad; REPO=$SP/c-4.5; cd $REPO
TW=$(git rev-parse t-twins); ALL=$(git rev-parse t-all)
F='FullyQualifiedName~EgressProducerTwinTests.RAGTool_never_labels|FullyQualifiedName~EgressProducerTwinTests.A_stores_other_ArgumentException|FullyQualifiedName~EgressProducerTwinTests.RAGTool_reports_read_nothing|FullyQualifiedName~EgressProducerTwinTests.RAGTool_labels_a_hit_at_a_custom_level'
L1=$SP/logs-4.5/red-attack-twins-${TW:0:8}.log
{ echo "== container run: $TW (twins alone, pre-fix RAGTool/VectorMath) =="; echo "== filter: $F"; bash scripts/test-in-container.sh --repo $REPO --ref $TW --framework net8.0 --filter "$F"; echo "== exit: $?"; } > $L1 2>&1
echo "== red run done: $(grep -E 'Passed!|Failed!' $L1 | tail -1)"
grep -E '^\s+Failed ' $L1 | sed 's/ \[.*//' | sort -u
L2=$SP/logs-4.5/filter-both-${ALL:0:8}.log
CMD=$(grep -v '^set -e' $SP/logs-4.5/run-filter-both.sh | tr '\n' ';')
{ echo "== container run: $ALL =="; echo "== $CMD"; bash scripts/test-in-container.sh --repo $REPO --ref $ALL -- "$CMD"; echo "== exit: $?"; } > $L2 2>&1
echo "== green run done:"; grep -E 'Warning\(s\)|Error\(s\)|Passed!|Failed!|^\s+Failed |error CS|== abstractions|== filter|== exit' $L2 | tail -14
echo "=== chain A done ($(date -u +%H:%M:%S))"
