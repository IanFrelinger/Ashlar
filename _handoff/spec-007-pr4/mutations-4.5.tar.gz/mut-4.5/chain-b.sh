#!/usr/bin/env bash
# Chain B: (1) the G5 hostile twin alone against the old shape (red expected), (2) mutation batch 2 at t-all.
set -u
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad; REPO=$SP/c-4.5; cd $REPO
G5=$(git rev-parse t-g5); ALL=$(git rev-parse t-all)
L1=$SP/logs-4.5/red-g5-twin-${G5:0:8}.log
{ echo "== container run: $G5 (G5 hostile twin alone, labelled tool handed the ReadScope) =="; bash scripts/test-in-container.sh --repo $REPO --ref $G5 --framework net8.0 --filter 'FullyQualifiedName~EgressProducerTwinTests.A_labelled_tool_cannot_complete|FullyQualifiedName~EgressProducerTwinTests.A_labelled_tool_that_reports_and_then_throws'; echo "== exit: $?"; } > $L1 2>&1
echo "== red G5 run done: $(grep -E 'Passed!|Failed!' $L1 | tail -1)"; grep -E '^\s+Failed |error CS|error xUnit|Expected' $L1 | head -8 | cut -c1-220
bash $SP/mut-4.5/run-mutations.sh $ALL m26-a-report-completes-the-read m04-agent-completes-the-read-before-invoking m23-ragtool-reads-nothing-for-every-ArgumentException m07-ragtool-maps-an-unknown-tier-to-public m08-ragtool-does-not-trim
echo "=== chain B done ($(date -u +%H:%M:%S))"
