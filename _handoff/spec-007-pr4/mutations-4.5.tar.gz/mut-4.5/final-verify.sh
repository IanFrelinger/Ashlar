#!/usr/bin/env bash
# Final verification at REF: the full cert-gate (net8.0), then the other touched test projects and the Tests.Infrastructure
# classes outside the Certification namespace that name the touched production classes.
set -u
SP=/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad; REPO=$SP/c-4.5; cd $REPO
REF=$(git rev-parse "$1"); S=${REF:0:8}
L=$SP/logs-4.5/cert-gate-$S.log
{ echo "== container run: $REF =="; echo "== bash scripts/run-cert-gate.sh"; bash scripts/test-in-container.sh --repo $REPO --ref $REF -- bash scripts/run-cert-gate.sh; echo "== exit: $?"; } > $L 2>&1
echo "== cert-gate: $(grep -E 'Total tests|skip guard' $L | tr '\n' ' ') failed-lines=$(grep -c '^\s*Failed ' $L)"
L=$SP/logs-4.5/other-projects-$S.log
CMD='for p in src/Ashlar.Tests.BackgroundAgents/Ashlar.Tests.BackgroundAgents.csproj src/Ashlar.Tests.AI.Pipeline/Ashlar.Tests.AI.Pipeline.csproj src/Ashlar.Tests.Orchestration/Ashlar.Tests.Orchestration.csproj; do echo "== project $p"; dotnet test $p --framework net8.0 --nologo -v minimal 2>&1 | grep -E "Passed!|Failed!|^\s+Failed |error CS"; done; echo "== infra non-cert filter"; dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj --framework net8.0 --filter "FullyQualifiedName~RuntimeStudioBlackBoxSmokeTests|FullyQualifiedName~GovernanceFloorPolicyTests|FullyQualifiedName~ToolEdgeGovernanceFloorTests" --nologo -v minimal 2>&1 | grep -E "Passed!|Failed!|^\s+Failed |error CS"; echo "== floors"; dotnet test src/Ashlar.Tests.Infrastructure/Ashlar.Tests.Infrastructure.csproj --framework net8.0 --filter "FullyQualifiedName~EgressGuardConventionTests.F6|FullyQualifiedName~EgressGuardConventionTests.F8" --nologo --logger "console;verbosity=detailed" 2>&1 | grep -E "ScannedFiles|DocsRows|Passed!|Failed!"'
{ echo "== container run: $REF =="; echo "== $CMD"; bash scripts/test-in-container.sh --repo $REPO --ref $REF -- "$CMD"; echo "== exit: $?"; } > $L 2>&1
grep -E '== project|== infra|== floors|Passed!|Failed!|^\s+Failed |error CS|ScannedFiles|DocsRows|== exit' $L
echo "=== final verify done ($(date -u +%H:%M:%S))"
