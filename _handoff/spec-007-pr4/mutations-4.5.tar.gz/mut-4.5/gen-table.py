#!/usr/bin/env python3
"""Builds the PR body's mutation table from mut-4.5/SUMMARY.txt and each run's log (red test names)."""
import re, os, collections
SP='/tmp/claude-0/-home-user-Ashlar/a81481a5-34f6-5b00-a61f-74b03c502c7b/scratchpad'
M=f'{SP}/mut-4.5'
DESC = {
 'm01': ('`BeginRead` enters the read\'s frame on the flow (the open-read rule)', '`Active.Value = read;` deleted'),
 'm02': ('The read\'s frame never names a decision', '`Frame.Live` stops at a read\'s frame (`(frame.IsDisposed || frame._isRead)` → `frame.IsDisposed`)'),
 'm03': ('The read\'s frame observes nothing of its own when disposed', '`if (Mark is not null && !_isRead)` → `if (Mark is not null)`'),
 'm04': ('`Complete()` only after the tool returned', '`read.Complete();` added before the `try`'),
 'm05': ('The agent hands the scope to the labelled tool', 'the call always goes through `tools.InvokeAsync`'),
 'm06': ('`RAGTool` reports each hit\'s label', 'the per-hit `read.Report(HitLabel(...))` becomes a discard'),
 'm07': ('An unknown tier is `SystemHigh`', '`: SecurityLabel.SystemHigh;` → `: SecurityLabel.Public;` in `HitLabel`'),
 'm08': ('`RAGTool` trims the tier', '`var trimmed = tier.Trim();` → `var trimmed = tier;`'),
 'm09': ('A custom level is `SystemHigh`', 'the `DataSensitivityLevels.All` reference check dropped'),
 'm10': ('The stores\' refusal reports "read nothing"', '`read?.Report(SecurityLabel.Public);` in the refusal path deleted'),
 'm11': ('No hits report "read nothing"', 'the `read.Report(SecurityLabel.Public);` before the hits deleted'),
 'm12': ('`peer:` and unknown-kind targets are agent-backed', '`IsAgentBacked` → `targetKey is null`'),
 'm13': ('A streamed response is observed before each update reaches the caller', 'the `ObserveResponse();` before `yield return update;` deleted'),
 'm14': ('Self-extend declares its frame', 'the `using var subject = EgressSubject.Enter(...)` line deleted'),
 'm15': ('Self-extend\'s floor is `SystemHigh`', '`new HighWaterMark(SecurityLabel.SystemHigh)` → `new HighWaterMark(SecurityLabel.Public)`'),
 'm16': ('Every production `Enter` is a `using`', '`using var subject =` → `var subject =`'),
 'm17': ('A `local:`/`cloud:` model\'s response is not a read', '`IsAgentBacked` → `true`'),
 'm18': ('The end of a stream is observed', 'the stream iterator\'s `finally { ObserveResponse(); }` → `GC.KeepAlive(updates)`'),
 'm19': ('The end of a response is observed, however it ends', '`ObservedAsync(Task)`\'s `finally { ObserveResponse(); }` → `GC.KeepAlive(call)`'),
 'm20': ('A synchronous throw under the guard is observed (response route)', 'the `ObserveResponse();` in `GetResponseAsync`\'s catch deleted'),
 'm21': ('A synchronous throw under the guard is observed (stream route)', 'the `ObserveResponse();` in `GetStreamingResponseAsync`\'s catch deleted'),
 'm22': ('Only `RAGTool` declares itself labelled in production', '`RepoFsReadTool : ILabelledTool` with a `Public`-reporting `InvokeLabelledAsync` planted'),
 'm23': ('Only the stores\' own refusal is "read nothing"', '`if (VectorMath.IsUnrankableQuery(ex))` dropped: every `ArgumentException` reports `Public`'),
 'm24': ('A tier is accepted only in a spelling `TrustTierOrder` ranks', 'the `CanonicalSpellings` check deleted'),
 'm26': ('The report channel a labelled tool is handed cannot complete the read', '`ReadReporter.Report` also calls `_scope.Complete()`'),
 'm25': ('No `using` alias of `EgressSubject` in production', '`using ES = Ashlar.Abstractions.Security.Egress.EgressSubject;` planted in `PlannerScratchpad.cs`'),
}
rows=[]
for line in open(f'{M}/SUMMARY.txt'):
    line=line.strip()
    m=re.match(r'mutation (m\d\d)(\S*): (.*)', line)
    if not m: continue
    mid, rest, verdict = m.group(1), m.group(2), m.group(3)
    log=f'{M}/{mid}{rest}.log'
    red=[]
    if os.path.exists(log):
        for l in open(log, errors='replace'):
            mm=re.match(r'\s+Failed (\S+)', l)
            if mm: red.append(mm.group(1).split('Certification.')[-1])
    red=sorted(set(red))
    # collapse theory cases
    groups=collections.OrderedDict()
    for r in red:
        base=r.split('(')[0]; groups.setdefault(base, 0); groups[base]+=1
    names='; '.join(f'`{b}`' + (f' ({c} cases)' if c>1 else '') for b,c in groups.items()) or '—'
    rule, mut = DESC.get(mid, ('?', '?'))
    rows.append(f'| {mid} | {rule} | {mut} | `{line}` | {names} |')
print('| # | Rule | Mutation | Summary line (verbatim) | What went red |')
print('|---|---|---|---|---|')
print('\n'.join(rows))
